//
//  SearchresultViewController.m
//  BSMusic
//
//  Created by tarena on 16/4/22.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "SearchresultViewController.h"
#import "rightViewController.h"
#import <Masonry.h>
#import "MusicListTableViewCell.h"
#import "NetworkHelper.h"
#import "MusicModel.h"
#import "PlayingViewController.h"
#import "BottomPlayView.h"
#import "MusicUrlModel.h"
#import "DateBaseManager.h"
@interface SearchresultViewController ()<UITableViewDelegate, UITableViewDataSource>{
    NSInteger pIndex; //上次播放的索引
}

@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataSourceArr;
@end

@implementation SearchresultViewController

-(NSMutableArray *)dataSourceArr{
    if (!_dataSourceArr) {
        _dataSourceArr = [NSMutableArray array];
    }
    return _dataSourceArr;
}

- (void)viewWillAppear:(BOOL)animated{
    [self getSearchMusicListData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"搜索结果";
    self.navigationController.navigationBar .tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"返回"style:UIBarButtonItemStyleBordered target:self action:@selector(backAction)];
    self.view.backgroundColor = [UIColor whiteColor];
    UISwipeGestureRecognizer *recognize = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(OnLeftButton)];
    [recognize setDirection:(UISwipeGestureRecognizerDirectionRight|UISwipeGestureRecognizerDirectionLeft)];
    [self.view addGestureRecognizer:recognize];
    [self.view addSubview:[BottomPlayView shareBottomPlayView]];
}
- (void)backAction{
   [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)OnLeftButton{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]init];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerNib:[UINib nibWithNibName:@"MusicListTableViewCell" bundle:nil] forCellReuseIdentifier:@"MusicListTableViewCell"];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
             make.top.left.bottom.right.mas_equalTo(self.view).insets(UIEdgeInsetsMake(64, 0, 50, 0));
        }];
    }
    return _tableView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  _dataSourceArr.count;
}
- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MusicModel *model = _dataSourceArr[indexPath.row];
    MusicListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MusicListTableViewCell" forIndexPath:indexPath];
    cell.SongName.text = [NSString stringWithFormat:@"%d. %@", (int)indexPath.row + 1, model.song_name];
    cell.model = model;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 90;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        //处理，点击的还是同一首歌
        if (pIndex != indexPath.row -1) {
            BottomPlayView *bpv = [BottomPlayView shareBottomPlayView];
            MusicModel *model = _dataSourceArr[indexPath.row];
            bpv.dataSourceArr = _dataSourceArr;
            bpv.currentIndex = indexPath.row;

            MusicUrlModel *url = [MusicUrlModel new];
            url.music_url = [[model.url_list firstObject] valueForKey:@"url"];
            
            //保存一份数据给数据库
            [self InsertData:model.song_name SingerName:model.singer_name FavoriteCount:model.pick_count MusicUrl:url.music_url];
            [bpv setupPlayerWithModel:model];
            pIndex = indexPath.row;
            
        }
    }
}

#pragma mark - 数据库方法
- (void)InsertData:(NSString *)SongName SingerName:(NSString *)SingerName FavoriteCount:(NSInteger)FavoriteCount MusicUrl:(NSString*)MusicUrl{
    if ([[DateBaseManager sharedDatabase] open]) {
        BOOL isSuccess = [[DateBaseManager sharedDatabase] executeUpdateWithFormat:@"insert into music (song_name, songer_name, pick_count, music_url) values (%@, %@, %ld, %@)",SongName,SingerName,(long)FavoriteCount,MusicUrl];
        
        if (!isSuccess) {
            NSLog(@"插入数据失败:%@",[DateBaseManager sharedDatabase].lastError);
        }
    }
}


#pragma mark - 数据类
- (void)getSearchMusicListData {
    
    [NetworkHelper JsonDataWithUrl:[NSString stringWithFormat:@"http://search.dongting.com/song/search/old?q=%@&page=1&size=100", self.text]success:^(id data) {
     
        NSArray *sectionArr = data[@"data"];
        for (NSDictionary *dictSection  in sectionArr) {
            MusicModel *modelSection = [MusicModel new];
            [modelSection setValuesForKeysWithDictionary:dictSection];
            
            [self.dataSourceArr addObject:modelSection];
            [self.tableView reloadData];
            
        }
    } fail:^{
        
    } view:self.view parameters:nil];
    
}
@end
