//
//  PlayMusicTableViewCell.m
//  BSMusic
//
//  Created by tarena on 16/4/13.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "PlayMusicTableViewCell.h"

@implementation PlayMusicTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
