//
//  Music.m
//  BSMusic
//
//  Created by tarena on 16/4/13.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "Music.h"

@implementation Music

@end
