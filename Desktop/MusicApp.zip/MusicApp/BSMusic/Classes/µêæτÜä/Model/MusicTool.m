//
//  MusicTool.m
//  BSMusic
//
//  Created by tarena on 16/4/13.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "MusicTool.h"

@implementation MusicTool
/** 所有歌曲*/
static NSArray *_musicArray;

/** 当前正在播放歌曲*/
static Music *_playingMusic;

/** 获取所有音乐(单例)*/
+ (NSArray *)musicArray
{
    if (!_musicArray) {
        _musicArray = [MusicTool getMusicFromPlistFile:@"Musics.plist"];
    }
    return _musicArray;
}

+ (NSArray *)getMusicFromPlistFile:(NSString *)plistName {
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:plistName ofType:nil];
    NSArray *musicArray = [[NSArray alloc] initWithContentsOfFile:plistPath];
    
    //声明可变数组，存储转换后的模型对象
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *musicDic in musicArray) {
        Music *music = [Music new];
        [music setValuesForKeysWithDictionary:musicDic];
        [mutableArray addObject:music];
    }
    
    return [mutableArray copy];
}


/** 设置当前正在播放的音乐*/
+ (void)setCurrentPlayingMusic:(Music *)music
{
    // 判断传入的音乐模型是否为nil
    // 判断数组中是否包含该音乐模型
    if (!music || ![_musicArray containsObject:music]) {
        return;
    }
    _playingMusic = music;
}

/** 返回当前正在播放的音乐*/
+ (Music *)currentPlayingMusic
{
    return _playingMusic;
}

/** 获取下一首*/
+ (Music *)nextMusic
{
    // 1.获取当前播放的索引
    NSUInteger currentIndex = [_musicArray indexOfObject:_playingMusic];
    // 2.计算下一首的索引
    NSInteger nextIndex = currentIndex + 1;
    // 3.越界处理
    if (nextIndex >= _musicArray.count) {
        nextIndex = 0;
    }
    // 4.取出下一首的模型返回
    return _musicArray[nextIndex];
}

/** 获取上一首*/
+ (Music *)previousMusic
{
    // 1.获取当前播放的索引
    NSUInteger currentIndex = [_musicArray indexOfObject:_playingMusic];
    // 2.计算上一首的索引
    NSInteger perviouesIndex = currentIndex - 1;
    // 3.越界处理
    if (perviouesIndex < 0) {
        perviouesIndex = _musicArray.count - 1;
    }
    // 4.取出下一首的模型返回
    return _musicArray[perviouesIndex];
}
@end
