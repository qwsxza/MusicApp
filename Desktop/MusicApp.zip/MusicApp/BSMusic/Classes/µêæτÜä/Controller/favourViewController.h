//
//  favourViewController.h
//  BSMusic
//
//  Created by MyMac on 16/5/1.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface favourViewController : UIViewController

@end
