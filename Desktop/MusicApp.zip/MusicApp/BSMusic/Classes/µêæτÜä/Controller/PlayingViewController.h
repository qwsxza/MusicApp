//
//  PlayingViewController.h
//  BSMusic
//
//  Created by tarena on 16/4/14.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@class MusicModel;
@interface PlayingViewController : UIViewController
@property (nonatomic, strong) UINavigationController *navigation;
@property (nonatomic, strong) NSMutableArray *dataArr;
@property (nonatomic, assign) NSInteger currentIndex;
@property (nonatomic, copy)   NSString *pic_url;
@property (nonatomic,strong) MusicModel *model;

@property (nonatomic, strong) AVPlayerItem *currentItem;
// 显示详情
- (void)showPlayingView;
- (void)showPlayView;
/** 创建全局播放的playViewController*/
+ (PlayingViewController *)sharePlayViewController;
@end
