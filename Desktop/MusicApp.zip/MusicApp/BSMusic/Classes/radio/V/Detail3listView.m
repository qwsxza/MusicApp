//
//  Detail3listView.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "Detail3listView.h"
#import "listCell.h"
#import "HeadviewCell.h"

@interface Detail3listView ()<UITableViewDataSource, UITableViewDelegate>

@end

@implementation Detail3listView



-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        
        self.tableview = [[UITableView alloc] initWithFrame:(CGRectMake(0, 0, frame.size.width, frame.size.height)) style:(UITableViewStylePlain)];
        [self addSubview:self.tableview];
        
        self.tableview.dataSource = self;
        self.tableview.delegate = self;
        
    }
    return self;
}


-(void)setModelArr:(NSMutableArray *)modelArr
{
    _modelArr = modelArr;
    
    [self.tableview reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.modelArr.count ;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
 /*
//    if (indexPath.row == 0) {
//        
//        static NSString *identifier = @"headcell";
//        //
//        
//        HeadviewCell *cell = [tableView dequeueReusableCellWithIdentifier: identifier];
//        if (cell == nil) {
//            cell = [[HeadviewCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier];
//        }
//        cell.infonation = self.infonation;
//        return cell;
//
//        
//    }
*/    
    
    static NSString *identifier = @"listcell";
    //
    
    listCell *cell = [tableView dequeueReusableCellWithIdentifier: identifier];
    if (cell == nil) {
        cell = [[listCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier];
    }
    if (indexPath.row <= self.modelArr.count - 1) {
        
        cell.list = self.modelArr[indexPath.row];
    }
    return cell;
    
    
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
