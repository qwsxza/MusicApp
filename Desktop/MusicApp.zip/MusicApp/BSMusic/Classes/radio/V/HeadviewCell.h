//
//  HeadviewCell.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "radioINfo.h"

@interface HeadviewCell : UITableViewCell

@property(nonatomic, strong)radioINfo *infonation;


@end
