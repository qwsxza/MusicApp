//
//  radioView.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface radioView : UIView

@property(nonatomic, strong)NSMutableArray *headArr;

@property(nonatomic, strong)NSMutableArray *secondArr;

@property(nonatomic, strong)NSMutableArray *cellArr;

@property(nonatomic, strong)UITableView *tableView;

@end
