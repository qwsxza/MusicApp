//
//  sceondCell.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIButton+WebCache.h"

@interface sceondCell : UITableViewCell

@property(nonatomic, strong)NSMutableArray *modelArr;

@property(nonatomic, strong)UIButton *dailyB;//每日精选
@property(nonatomic, strong)UIButton *voice;//最新发声
@property(nonatomic, strong)UIButton *nanaya;//七夜


@end
