//
//  OneView.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "playINFO.h"

@interface OneView : UIView


@property(nonatomic, strong)playINFO *play;

@property(nonatomic, strong)UIImageView *imageV;

@property(nonatomic, strong)UISlider *silder;
@property(nonatomic, strong)UILabel *titlelabel;
@property(nonatomic, strong)UILabel *timelabel;
@property(nonatomic, strong)UILabel *totallabel;

@end
