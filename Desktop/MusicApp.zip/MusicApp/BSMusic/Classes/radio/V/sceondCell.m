//
//  sceondCell.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "sceondCell.h"
#import "two.h"
#import "radioDetailViewController.h"

@implementation sceondCell


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        
        self.dailyB = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.contentView addSubview:self.dailyB];
        self.dailyB.tag = 1000;
        self.voice = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.contentView addSubview:self.voice];
        self.voice.tag = 1001;
        self.nanaya = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.contentView addSubview:self.nanaya];
        self.nanaya.tag = 1002;
        self.dailyB.frame = CGRectMake(5, 0, [UIScreen mainScreen].bounds.size.width / 3 - 15 , 115);
        self.voice.frame = CGRectMake(self.dailyB.frame.origin.x + self.dailyB.frame.size.width + 10, 0, self.dailyB.frame.size.width , 115);
        self.nanaya.frame = CGRectMake(self.voice.frame.origin.x + self.voice.frame.size.width + 10, 0, self.voice.frame.size.width , 115);

        
        [self.dailyB addTarget:self action:@selector(toNext:) forControlEvents:(UIControlEventTouchUpInside)];
        [self.voice addTarget:self action:@selector(toNext:) forControlEvents:(UIControlEventTouchUpInside)];
        [self.nanaya addTarget:self action:@selector(toNext:) forControlEvents:(UIControlEventTouchUpInside)];
        
//        self.dailyB.backgroundColor = [UIColor redColor];
//        self.voice.backgroundColor = [UIColor blackColor];
//        self.nanaya.backgroundColor = [UIColor purpleColor];

        
    }
    return self;
}

-(void)toNext:(UIButton *)button
{
    UIViewController *VC = [self viewController];
    
    radioDetailViewController *radioVC = [[radioDetailViewController alloc] init];
    two *too = [self.modelArr objectAtIndex:button.tag - 1000];

    radioVC.API = too.radioid;
    radioVC.title = too.title;
    [VC.navigationController pushViewController:radioVC animated:YES];
    
    
}


- (UIViewController*)viewController
{
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}


-(void)setModelArr:(NSMutableArray *)modelArr
{
    _modelArr = modelArr;
    
    NSMutableArray *arr = [NSMutableArray arrayWithObjects:self.dailyB, self.voice, self.nanaya, nil];
    
    if (modelArr.count == 3) {
        
    for (int i = 0; i < modelArr.count; i++) {
        two *sec = [modelArr objectAtIndex:i];
        [arr[i] sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", sec.coverimg]] forState:(UIControlStateNormal)];
    }
    }
}




- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
