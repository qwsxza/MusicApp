//
//  radioView.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "radioView.h"
#import "scrollCell.h"
#import "sceondCell.h"
#import "alllistCell.h"

@interface radioView ()<UITableViewDataSource, UITableViewDelegate>

@end


@implementation radioView

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
    
        self.tableView = [[UITableView alloc] initWithFrame:(CGRectMake(0, 0, frame.size.width, frame.size.height)) style:(UITableViewStylePlain)];
        
        [self addSubview:self.tableView];
        
        self.tableView.dataSource = self;
        
    }
    return self;
}

-(void)setHeadArr:(NSMutableArray *)headArr
{
    _headArr = headArr;
    
    [self.tableView reloadData];
}

-(void)setSecondArr:(NSMutableArray *)secondArr
{
    _secondArr = secondArr;
    [self.tableView reloadData];
}

-(void)setCellArr:(NSMutableArray *)cellArr
{
    _cellArr = cellArr;
    
    [self.tableView reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        
        return 2;
    } else{
        
        return self.cellArr.count;
    }
    
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        
    
    if (indexPath.row == 0) {
    static NSString *identifier = @"head";
    //
    
    scrollCell *cell = [tableView dequeueReusableCellWithIdentifier: identifier];
    if (cell == nil) {
        cell = [[scrollCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier] ;
    }
        
        if (cell.modelArray == nil) {
            
            cell.modelArray = self.headArr;
        }
        
    return cell;
    }
   
    //
    if (indexPath.row == 1) {
        
    static NSString *identifier1 = @"second";
        //
        
    sceondCell *cell = [tableView dequeueReusableCellWithIdentifier: identifier1];
    if (cell == nil) {
            cell = [[sceondCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier1] ;
    }
    cell.modelArr = self.secondArr;

            return cell;
   
    }
    }
   
        
    
    
    static NSString *identifier = @"list";
        
    alllistCell *cell = [tableView dequeueReusableCellWithIdentifier: identifier];
    if (cell == nil) {
        cell = [[alllistCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier];
    }
    if (indexPath.row <= self.cellArr.count - 1) {
        
        cell.list = self.cellArr[indexPath.row];
    }
    
    return cell;
        
    
    
}




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
