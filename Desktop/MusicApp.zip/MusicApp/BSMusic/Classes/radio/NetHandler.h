//
//  NetHandler.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NetHandler : NSObject
// 根据网络请求的特点，不同的地方就是请求地址和分析数据的方式不同，就把这两部分分别作为方法参数

+ (void)getDataWithUrl:(NSString *)str completion:(void(^)(NSData *data))block;
@end
