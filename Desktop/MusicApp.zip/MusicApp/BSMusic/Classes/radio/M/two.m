//
//  two.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "two.h"

@implementation two

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
