//
//  NetworkHelper.m
//  BSMusic
//
//  Created by tarena on 16/4/15.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "NetworkHelper.h"
#import "MBProgressHUD.h"
#import "AFNetworking.h"

@implementation NetworkHelper
+ (void)JsonDataWithUrl:(NSString*)url success:(void(^)(id data))success fail:(void(^)())fail view:(UIView *)view parameters:(NSDictionary*)parameters{
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    [[AFNetworkReachabilityManager sharedManager]setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        if (status <=0) {
            MBProgressHUD *mb1 = [MBProgressHUD showHUDAddedTo:view animated:YES];
            mb1.mode = MBProgressHUDModeText;
            mb1.labelText = @"当前无网络";
            [mb1 hide:YES afterDelay:1];
        }else{
            MBProgressHUD *mb = [MBProgressHUD showHUDAddedTo:view animated:YES];
            mb.mode = MBProgressHUDModeIndeterminate;
            mb.labelText = @"拼命加载中";
            //AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
            AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
            [manager GET:url parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                if (responseObject) {
                    [mb removeFromSuperview];
                    if (success) {
                        success(responseObject);
                    }
                }
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                [mb removeFromSuperview];
                if (fail) {
                    fail();
                }
            }];
         
        }
    }];
}
@end
