//
//  PlayerHelper.h
//  BSMusic
//
//  Created by tarena on 16/4/21.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
@interface PlayerHelper : NSObject
@property (nonatomic, strong) AVQueuePlayer *aPlayer;

+ (instancetype)sharePlayerHelper;
@end
