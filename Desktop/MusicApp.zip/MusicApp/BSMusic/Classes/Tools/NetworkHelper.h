//
//  NetworkHelper.h
//  BSMusic
//
//  Created by tarena on 16/4/15.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NetworkHelper : NSObject
+ (void)JsonDataWithUrl:(NSString*)url success:(void(^)(id data))success fail:(void(^)())fail view:(UIView *)view parameters:(NSDictionary*)parameters;
@end
