//
//  HomePagetableVcCell.h
//  BSMusic
//
//  Created by tarena on 16/4/11.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ViewChangeProtocol <NSObject>
-(void)getbtnType:(NSString*)tag;

@end

typedef void(^btnTypeBlock)(NSString *tag);
@interface HomePagetableVcCell : UITableViewCell
@property (nonatomic,strong)id<ViewChangeProtocol> delegate;
- (void) sendBlock:(btnTypeBlock)block;
@end
