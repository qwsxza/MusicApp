//
//  MusicUrlModel.h
//  BSMusic
//
//  Created by MyMac on 16/5/10.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MusicUrlModel : NSObject

@property (nonatomic,copy) NSString* music_url;
@end
