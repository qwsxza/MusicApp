//
//  MainMusicModel.h
//  BSMusic
//
//  Created by tarena on 16/4/15.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MainMusicModel : NSObject
/** 分区名字 */
@property (nonatomic, copy) NSString *name, *desc;
/** 暂时不知 */
@property (nonatomic, strong) NSNumber *style;
/** id和数量*/
@property (nonatomic, strong) NSNumber *_id, *order;

@property (nonatomic, strong) NSMutableArray *data;

@property (nonatomic, strong) NSDictionary *action;

@property (nonatomic, strong) NSString *pic_url, *listen_count, *author, *ID;
@end
