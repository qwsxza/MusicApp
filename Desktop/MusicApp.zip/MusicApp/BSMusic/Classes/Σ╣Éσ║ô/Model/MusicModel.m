//
//  MusicModel.m
//  BSMusic
//
//  Created by MyMac on 16/4/19.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "MusicModel.h"
#import "DateBaseManager.h"

@implementation MusicModel
- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"songId"]) {
        self.song_id = value;
    }
    if ([key isEqualToString:@"singerName"]) {
        self.singer_name = value;
    }
    if ([key isEqualToString:@"name"]) {
        self.song_name = value;
    }
    
    if ([key isEqualToString:@"albumName"]) {
        self.album_name = value;
    }
    if ([key isEqualToString:@"urlList"]) {
        self.url_list = value;
    }
    
    if ([key isEqualToString:@"favorites"]) {
        self.pick_count = [value integerValue];
    }
}

+ (NSMutableArray *)kinds {
    FMDatabase *database = [DateBaseManager sharedDatabase];
    FMResultSet *resultSet = [database executeQuery:@"select * from music"];
    NSMutableArray *mutablArray = [NSMutableArray array];
    
    while ([resultSet next]) {
        MusicModel *music = [self new];
        music.song_name = [resultSet stringForColumn:@"song_name"];
        music.singer_name = [resultSet stringForColumn:@"songer_name"];
        music.pick_count = [resultSet doubleForColumn:@"pick_count"];
        
        //添加赋值后的诗集对象
        [mutablArray addObject:music];
        NSLog(@"");
    }
    return [mutablArray copy];
}

@end
