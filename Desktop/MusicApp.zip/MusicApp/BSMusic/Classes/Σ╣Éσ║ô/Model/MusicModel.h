//
//  MusicModel.h
//  BSMusic
//
//  Created by MyMac on 16/4/19.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MusicModel : NSObject
@property (nonatomic, strong) NSNumber *singer_id, *song_id;
@property (nonatomic, copy) NSString *singer_name, *song_name;
@property (nonatomic, copy) NSString *album_name;//专辑名字
@property (nonatomic, strong) NSNumber *album_id;//专辑id
@property (nonatomic, assign) NSInteger pick_count;

@property (nonatomic, copy) NSString *pic_url;  //存储歌曲图片

@property (nonatomic, strong) NSMutableArray *url_list;

+ (NSMutableArray *)kinds;
@end
