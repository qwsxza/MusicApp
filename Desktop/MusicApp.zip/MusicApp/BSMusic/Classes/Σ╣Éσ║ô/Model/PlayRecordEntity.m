//
//  PlayRecordEntity.m
//  BSMusic
//
//  Created by tarena on 16/4/21.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "PlayRecordEntity.h"

@implementation PlayRecordEntity
@dynamic songName;
@dynamic songPlayCount;
@dynamic songImage;
@dynamic songUrl;
@dynamic songFrom;
@dynamic songSinger;
@dynamic songID;
@dynamic autoID;
@end
