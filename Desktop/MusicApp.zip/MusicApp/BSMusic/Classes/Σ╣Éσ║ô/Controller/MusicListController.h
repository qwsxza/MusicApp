//
//  MusicListController.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MusicListController : UIViewController
@property (nonatomic, copy)   NSString *navTitile;
@property (nonatomic, copy) NSString *msg_id;
/** 用来接收从排行传过来的图片*/
@property (nonatomic, copy) NSString *pic_url;
@end
