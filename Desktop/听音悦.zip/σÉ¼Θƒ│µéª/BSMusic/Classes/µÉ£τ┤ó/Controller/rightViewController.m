//
//  rightViewController.m
//  BSMusic
//
//  Created by tarena on 16/4/21.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "rightViewController.h"
#import <Masonry.h>
#import "SearchresultViewController.h"
#import "NetworkHelper.h"
#import "SearchresultViewController.h"

@interface rightViewController ()<UISearchBarDelegate>
@property (weak, nonatomic) IBOutlet UISearchBar *searchbar;
@end

@implementation rightViewController

#pragma mark - 生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    self.searchbar.delegate = self;
}

#pragma mark - UISearchBar代理方法
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    NSString *mysearch=[searchBar text];
    
    NSString * encodingString = [mysearch stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    SearchresultViewController *vc = [[SearchresultViewController alloc]init];
    vc.text = encodingString;
    UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:vc];
    [self presentViewController:navi animated:YES completion:nil];
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}


@end
