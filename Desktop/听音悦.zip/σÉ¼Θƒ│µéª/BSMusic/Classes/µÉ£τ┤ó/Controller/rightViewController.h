//
//  rightViewController.h
//  BSMusic
//
//  Created by tarena on 16/4/21.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol SearchProtocol <NSObject>
-(void)getMessageText:(NSString*)text;

@end

@interface rightViewController : UIViewController
@property (nonatomic,strong)id<SearchProtocol> delegate;
@end
