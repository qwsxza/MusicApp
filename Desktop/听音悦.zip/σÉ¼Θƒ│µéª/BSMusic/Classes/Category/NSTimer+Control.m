//
//  NSTimer+Control.m
//  BSMusic
//
//  Created by tarena on 16/4/21.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "NSTimer+Control.h"

@implementation NSTimer (Control)
-(void)pauseTimer
{
    if (![self isValid]) {
        return ;
    }
    [self setFireDate:[NSDate distantFuture]];
}


-(void)resumeTimer
{
    if (![self isValid]) {
        return ;
    }
    [self setFireDate:[NSDate date]];
}

- (void)resumeTimerAfterTimeInterval:(NSTimeInterval)interval
{
    if (![self isValid]) {
        return ;
    }
    [self setFireDate:[NSDate dateWithTimeIntervalSinceNow:interval]];
}
@end
