//
//  MusicListTableViewCell.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "MusicListTableViewCell.h"
#import "MusicModel.h"
#import "UIImageView+WebCache.h"

@implementation MusicListTableViewCell

- (void)awakeFromNib {
 
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}
- (void)setModel:(MusicModel *)model {
    self.SingerName.text = model.singer_name;
    self.FavoriteCount.text = [NSString stringWithFormat:@"%ld", (long)model.pick_count];
}
@end
