//
//  HomePageViewCell.h
//  BSMusic
//
//  Created by tarena on 16/4/11.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainMusicModel.h"
@interface HomePageViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *titleImage;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblDesc;
@property (nonatomic, strong) MainMusicModel *model;
@end
