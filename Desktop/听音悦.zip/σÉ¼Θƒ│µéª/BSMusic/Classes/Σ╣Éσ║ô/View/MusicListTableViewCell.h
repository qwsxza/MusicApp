//
//  MusicListTableViewCell.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MusicModel;
@interface MusicListTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *SongName;
@property (weak, nonatomic) IBOutlet UILabel *SingerName;
@property (weak, nonatomic) IBOutlet UILabel *FavoriteCount;

@property (nonatomic, strong) MusicModel *model;
@end
