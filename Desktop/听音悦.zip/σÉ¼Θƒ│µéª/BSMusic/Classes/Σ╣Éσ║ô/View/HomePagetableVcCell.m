//
//  HomePagetableVcCell.m
//  BSMusic
//
//  Created by tarena on 16/4/11.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "HomePagetableVcCell.h"


@interface HomePagetableVcCell()
{
    btnTypeBlock _resultBlock;
}

@end
@implementation HomePagetableVcCell
- (IBAction)PopListen:(id)sender {
    //NSLog(@"1");
   
    [self.delegate getbtnType:@"1"];
   // _resultBlock(@"1");
}


- (IBAction)Singer:(id)sender {
    NSLog(@"2");
    [self.delegate getbtnType:@"2"];
}
- (IBAction)Rank:(id)sender {
    NSLog(@"3");
    [self.delegate getbtnType:@"3"];
}


- (void)awakeFromNib {
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)sendBlock:(btnTypeBlock)block{
      _resultBlock = block;
}

@end
