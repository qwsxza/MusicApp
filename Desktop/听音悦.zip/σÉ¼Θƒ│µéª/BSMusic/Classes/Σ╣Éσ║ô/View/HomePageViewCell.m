//
//  HomePageViewCell.m
//  BSMusic
//
//  Created by tarena on 16/4/11.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "HomePageViewCell.h"
#import "UIImageView+WebCache.h"
@implementation HomePageViewCell

- (void)awakeFromNib {
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setModel:(MainMusicModel *)model {
    [self.titleImage sd_setImageWithURL:[NSURL URLWithString:model.pic_url] placeholderImage:[UIImage imageNamed:@"default.jpg"]];
    self.lblTitle.text = model.name;
    self.lblDesc.text = model.desc;
}
@end
