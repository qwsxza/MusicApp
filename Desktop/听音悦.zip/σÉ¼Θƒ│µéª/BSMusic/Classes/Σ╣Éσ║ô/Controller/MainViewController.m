//
//  MainViewController.m
//  BSMusic
//
//  Created by tarena on 16/4/11.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "MainViewController.h"
#import "HomePagetableVcCell.h"
#import "HomePageViewCell.h"
#import "LeftViewController.h"
#import <Masonry.h>
#import <SDCycleScrollView.h>
#import "ViewController.h"
#import "MainMusicModel.h"
#import "NetworkHelper.h"
#import "WebPageViewController.h"
#import "MusicListController.h"
#import "BottomPlayView.h"
#import "PlayingViewController.h"


@interface MainViewController()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataSourceArray;
@property (nonatomic, strong) NSMutableArray *dataSecion;
@property (nonatomic, strong) NSMutableArray *imageURLArr;

@end

@implementation MainViewController


#pragma mark - 懒加载

-(UITableView*)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]init];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerNib:[UINib nibWithNibName:@"HomePagetableVcCell" bundle:nil] forCellReuseIdentifier:@"HomePagetableVcCell"];
        [_tableView registerNib:[UINib nibWithNibName:@"HomePageViewCell" bundle:nil] forCellReuseIdentifier:@"HomePageViewCell"];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            //make.edges.mas_equalTo(0);
            make.top.left.bottom.right.mas_equalTo(self.view).insets(UIEdgeInsetsMake(0, 0, 0, 0));
        }];
    }
    return _tableView;
}

#pragma mark -生命周期
-(void)viewDidLoad{
    [super viewDidLoad];
    [self createcycleScrollView];
    [self setNavigationUI];
    self.dataSourceArray = [NSMutableArray array];
    self.dataSecion = [NSMutableArray array];
   // self.imageURLArr = [NSMutableArray array];
    
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (self.dataSourceArray.count > 0) {
        return;
    }
    [self readHotData];
    BottomPlayView *bpv = [BottomPlayView shareBottomPlayView];
    bpv.TapPlayView = ^(NSMutableArray *dataArr, NSInteger currentIndex,NSString *pic_url, AVPlayerItem *currentItem) {
        [PlayingViewController sharePlayViewController].dataArr = dataArr;
        [PlayingViewController sharePlayViewController].currentIndex = currentIndex;
        [PlayingViewController sharePlayViewController].currentItem = currentItem;
    };
    
}

-(void)OnRightButton{
    NSLog(@"----");
    UINavigationController *navi = [[UINavigationController alloc]init];
   ViewController *vc = [[ViewController alloc]init]
    ;
    [navi presentViewController:vc animated:YES completion:nil];
}
#pragma mark -设置导航栏的样式
-(void)setNavigationUI{
    self.navigationItem.title = @"乐库";
    [self.navigationController.navigationBar setBarTintColor:[UIColor blackColor]];

    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:0.1];
    //UIApplacation设置状态栏的样式
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    
    //设置导航条的标题的字体和颜色（NSForegroundColorAttributeName）
    NSDictionary *titleAttr = @{
                                NSForegroundColorAttributeName:[UIColor lightGrayColor],
                                NSFontAttributeName:[UIFont systemFontOfSize:20]
                                };
    [self.navigationController.navigationBar  setTitleTextAttributes:titleAttr];
    //UITextAttributeTextColor iOS7后被淘汰
    // self.navigationController.navigationBar.titleTextAttributes = @{UITextAttributeTextColor : [UIColor redColor]};
    //设置返回按钮的样式
    //tintColor是用于导航条的所有Item
    self.navigationController.navigationBar .tintColor = [UIColor lightGrayColor];
    
    
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"电台" style:UIBarButtonItemStylePlain target:self action:nil];
    //设置Item的字体大小
    [leftButtonItem setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]} forState:UIControlStateNormal];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
    
    UIBarButtonItem *rightButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"热搜" style:UIBarButtonItemStylePlain target:self action:@selector(OnRightButton)];
    //设置Item的字体大小
    [rightButtonItem setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]} forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = rightButtonItem;
}
#pragma mark -创建滑动视图
-(void)createcycleScrollView{
    NSArray *arr = @[@"image_01",@"image_02",@"image_03",@"image_04",@"image_05"];
    //NSArray *arr = _imageURLArr;
    SDCycleScrollView *cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 159) imageNamesGroup:arr];
    self.tableView.tableHeaderView = cycleScrollView;
}
#pragma mark - tableView的代理方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  
    return _dataSourceArray.count;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return section == 0? 1 : [_dataSourceArray[section] count];
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MainMusicModel *model = _dataSourceArray[indexPath.section][indexPath.row];
    if (indexPath.section==0) {
        HomePagetableVcCell* cell = [tableView dequeueReusableCellWithIdentifier:@"HomePagetableVcCell" forIndexPath:indexPath];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
        return cell;
    }else{
        HomePageViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HomePageViewCell" forIndexPath:indexPath];
       
        cell.model = model;
        return cell;
        
        
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section ==0) {
        return;
    }else{
        MainMusicModel *model = _dataSourceArray[indexPath.section][indexPath.row];
        if ([model.action[@"type"] isEqualToNumber:@(1)]) {
            WebPageViewController *web = [[WebPageViewController alloc] init];
            web.urlString = model.action[@"value"];
            UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:web];
            [self presentViewController:navi animated:YES completion:nil];
        }
        if([model.action[@"type"] isEqualToNumber:@(5)]){
            MusicListController *listTV = [[MusicListController alloc]init];
            listTV.msg_id = model.action[@"value"];
          
            //UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:listTV];
            [self.navigationController pushViewController:listTV animated:YES];
           // [self presentViewController:navi animated:YES completion:nil];
        }

  }
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==0) {
        return 40;
    }
    return 120;
}


#pragma mark - 数据类
/** 请求数据*/
- (void)readHotData {
    [NetworkHelper JsonDataWithUrl:@"http://api.dongting.com/frontpage/frontpage" success:^(id data) {
        NSArray *sectionArr = data[@"data"];
        int i = 0;
        for (NSDictionary *dictSection  in sectionArr) {
            MainMusicModel *modelSection = [MainMusicModel new];
            [modelSection setValuesForKeysWithDictionary:dictSection];
            
            NSArray *rowArr = dictSection[@"data"];
            NSMutableArray *tempArr = [NSMutableArray array];
            for (NSDictionary *dictRow in rowArr) {
                MainMusicModel *modelRow = [MainMusicModel new];
                [modelRow setValuesForKeysWithDictionary:dictRow];
                modelRow.ID = modelRow.action[@"value"];
                
                if(!modelRow.ID) {
                    continue;
                }
                
                if (i == 0) {
                    [_imageURLArr addObject:[NSURL URLWithString:modelRow.pic_url]];
                }
                
                [tempArr addObject:modelRow];
            }
            
            if (tempArr.count > 0) {
                [_dataSourceArray addObject:tempArr];
                [_dataSecion addObject:modelSection];
            }
            i++;
        }
        [self.tableView reloadData];

    } fail:^{
        
    } view:self.view parameters:nil];
}


@end
