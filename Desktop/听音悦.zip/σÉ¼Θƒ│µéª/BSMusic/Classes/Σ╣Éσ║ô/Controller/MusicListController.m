//
//  MusicListController.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "MusicListController.h"
#import <Masonry.h>
#import "MusicListTableViewCell.h"
#import "NetworkHelper.h"
#import "MusicModel.h"
#import "UIImageView+WebCache.h"
#import "PlayingViewController.h"
#import "BottomPlayView.h"
#import "LeftViewController.h"
#import "DateBaseManager.h"
#import "MusicUrlModel.h"

@interface MusicListController ()<UITableViewDelegate, UITableViewDataSource> {
    NSInteger pIndex; //上次播放的索引
}

@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataSourceArr;
@property (nonatomic, strong) NSMutableDictionary *userDict;
@property (nonatomic,strong) PlayingViewController *player;
@property (nonatomic,strong)MusicModel *model;
@end
@implementation MusicListController

#pragma mark -懒加载
-(MusicModel *)model
{
    if (!_model) {
        _model = (MusicModel *)[[MusicUrlModel alloc]init];
    }
    return _model;
}
-(NSMutableArray *)dataSourceArr{
    if (!_dataSourceArr) {
        _dataSourceArr = [NSMutableArray array];
    }
    return _dataSourceArr;
}



-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]init];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerNib:[UINib nibWithNibName:@"MusicListTableViewCell" bundle:nil] forCellReuseIdentifier:@"MusicListTableViewCell"];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.bottom.right.mas_equalTo(self.view).insets(UIEdgeInsetsMake(0, 0, 50, 0));
        }];
    }
    return _tableView;
}

#pragma mark -生命周期
- (void)viewWillLayoutSubviews{
    [self.view addSubview:[BottomPlayView shareBottomPlayView]];
}
- (void)viewWillAppear:(BOOL)animated{
    [self.tableView reloadData];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.player = [[PlayingViewController alloc]init];
    [self readMusicListData];
    
    //bug
    NSLog(@"%@",self.dataSourceArr);
   
    
    UISwipeGestureRecognizer *recognize = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(OnLeftButton)];
    [recognize setDirection:(UISwipeGestureRecognizerDirectionRight|UISwipeGestureRecognizerDirectionLeft)];
    [self.view addGestureRecognizer:recognize];
    
}

- (void)OnLeftButton{
   [self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma mark - tableView 代理方法
//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
//    return 1;
//}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  _dataSourceArr.count;
}


-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MusicModel *model = _dataSourceArr[indexPath.row];
    MusicListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MusicListTableViewCell" forIndexPath:indexPath];
    cell.SongName.text = [NSString stringWithFormat:@"%d. %@", (int)indexPath.row + 1  , model.song_name];
    cell.model = model;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 90;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
        //处理，点击的还是同一首歌
        if (pIndex != indexPath.row) {
            BottomPlayView *bpv = [BottomPlayView shareBottomPlayView];
            self.model = _dataSourceArr[indexPath.row];

            bpv.dataSourceArr = _dataSourceArr;
            bpv.currentIndex = indexPath.row;
            MusicUrlModel *url = [MusicUrlModel new];
            url.music_url = [[self.model.url_list firstObject] valueForKey:@"url"];
            
            //保存一份数据给数据库
            [self InsertData:self.model.song_name SingerName:self.model.singer_name FavoriteCount:self.model.pick_count MusicUrl:url.music_url];
           
            [bpv setupPlayerWithModel:self.model];
            pIndex = indexPath.row;
           
            
        }
    
}
#pragma mark - 数据库方法
- (void)InsertData:(NSString *)SongName SingerName:(NSString *)SingerName FavoriteCount:(NSInteger)FavoriteCount MusicUrl:(NSString*)MusicUrl{
    if ([[DateBaseManager sharedDatabase] open]) {
        BOOL isSuccess = [[DateBaseManager sharedDatabase] executeUpdateWithFormat:@"insert into music (song_name, songer_name, pick_count, music_url) values (%@, %@, %ld, %@)",SongName,SingerName,(long)FavoriteCount,MusicUrl];
        
        if (!isSuccess) {
            NSLog(@"插入数据失败:%@",[DateBaseManager sharedDatabase].lastError);
        }
    }
}

#pragma mark - 数据类
- (void)readMusicListData {
        [NetworkHelper JsonDataWithUrl:[NSString stringWithFormat:@"http://api.songlist.ttpod.com/songlists/%@", self.msg_id]success:^(id data) {
            NSArray *sectionArr = data[@"songs"];
            for (NSDictionary *dictSection  in sectionArr) {
                MusicModel *modelSection = [MusicModel new];
                [modelSection setValuesForKeysWithDictionary:dictSection];
            [_dataSourceArr addObject:modelSection];
            [self.tableView reloadData];

            }
        } fail:^{
            
        } view:self.view parameters:nil];
    
}
@end
