//
//  WebPageViewController.h
//  BSMusic
//
//  Created by MyMac on 16/4/19.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebPageViewController : UIViewController
@property (nonatomic, strong) NSString *urlString;
@end
