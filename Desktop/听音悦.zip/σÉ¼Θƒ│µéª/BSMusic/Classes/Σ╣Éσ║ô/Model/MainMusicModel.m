//
//  MainMusicModel.m
//  BSMusic
//
//  Created by tarena on 16/4/15.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "MainMusicModel.h"

@implementation MainMusicModel
- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"id"]) {
        self.ID = value;
    }
    if ([key isEqualToString:@"picUrl"]) {
        self.pic_url = value;
    }
    
    if ([key isEqualToString:@"listenCount"]) {
        self.listen_count = value;
    }
}
@end
