//
//  MusicUrlModel.m
//  BSMusic
//
//  Created by MyMac on 16/5/10.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "MusicUrlModel.h"

@implementation MusicUrlModel

@end
