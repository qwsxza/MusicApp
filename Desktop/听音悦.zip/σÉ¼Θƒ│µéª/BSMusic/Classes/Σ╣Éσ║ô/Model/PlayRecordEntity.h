//
//  PlayRecordEntity.h
//  BSMusic
//
//  Created by tarena on 16/4/21.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface PlayRecordEntity : NSManagedObject
@property (nonatomic, retain) NSString * songName;
@property (nonatomic, retain) NSString * songPlayCount;
@property (nonatomic, retain) NSString * songImage;
@property (nonatomic, retain) NSString * songUrl;
@property (nonatomic, retain) NSString * songFrom;
@property (nonatomic, retain) NSString * songSinger;
@property (nonatomic, retain) NSString * songID;
@property (nonatomic) int32_t autoID;
@end
