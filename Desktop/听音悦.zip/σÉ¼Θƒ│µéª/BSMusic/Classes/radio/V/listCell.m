//
//  listCell.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "listCell.h"
#import "UIImageView+WebCache.h"
#import "UIColor+AddColor.h"


@interface listCell ()

@property(nonatomic, strong)UIImageView *imageview;

@property(nonatomic, strong)UILabel *titlelabel;

@property(nonatomic, strong)UIImageView *radioV;

@property(nonatomic, strong)UILabel *count;

@property(nonatomic, strong)UIImageView *imageV;

@end

@implementation listCell



-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
     
        self.imageview = [[UIImageView alloc] initWithFrame:(CGRectMake(10, 5, [UIScreen mainScreen].bounds.size.width * 1/7, [UIScreen mainScreen].bounds.size.width * 1/7))];
        [self.contentView addSubview:self.imageview];
        
        self.titlelabel = [[UILabel alloc] initWithFrame:(CGRectMake(self.imageview.frame.origin.x + self.imageview.bounds.size.width + 10, 12, 260, 20))];
        [self.contentView addSubview:self.titlelabel];
        self.titlelabel.font = [UIFont boldSystemFontOfSize:16];
        
        self.radioV = [[UIImageView alloc] initWithFrame:(CGRectMake(self.titlelabel.frame.origin.x, self.titlelabel.frame.origin.y + self.titlelabel.bounds.size.height + 10, 15, 15))];
        self.count = [[UILabel alloc] initWithFrame:(CGRectMake(self.radioV.frame.origin.x + 20, self.radioV.frame.origin.y, 100, 15))];
        [self.contentView addSubview:self.radioV];
        [self.contentView addSubview:self.count];
        
        self.count.font = [UIFont boldSystemFontOfSize:13];
        self.imageV  = [[UIImageView alloc] initWithFrame:(CGRectMake([UIScreen mainScreen].bounds.size.width - 50, self.radioV.frame.origin.y, 15, 15))];
        [self.contentView addSubview:self.imageV];
        
    }
    return self;
}

-(void)setList:(detaillist *)list
{
    _list = list;
    
    self.radioV.image = [UIImage imageNamed:@"radio"];
    [self.imageview sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", list.coverimg]] placeholderImage:nil];
    self.titlelabel.text = list.title;
    self.count.text = list.musicVisit;
    self.imageV.image = [UIImage imageNamed:@"bofang"];
    
    
    
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
