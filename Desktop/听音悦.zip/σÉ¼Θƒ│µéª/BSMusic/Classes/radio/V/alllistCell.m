//
//  alllistCell.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "alllistCell.h"
#import "UIImageView+WebCache.h"
#import "UIColor+AddColor.h"
#import "UIView+Extension.h"


@interface alllistCell ()

@property(nonatomic, strong)UIImageView *imageV;
@property(nonatomic, strong)UILabel *title;
@property(nonatomic, strong)UILabel *author;
@property(nonatomic, strong)UILabel *des;
@property(nonatomic, strong)UILabel *count;
@property(nonatomic, strong)UIImageView *listenV;



@end

@implementation alllistCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.imageV = [[UIImageView alloc] initWithFrame:(CGRectMake(5, 5, [UIScreen mainScreen].bounds.size.width * 1/5, 75))];
        [self.contentView addSubview:self.imageV];
        
        self.title = [[UILabel alloc] initWithFrame:(CGRectMake(self.imageV.frame.origin.x + self.imageV.frame.size.width + 10, 10, [UIScreen mainScreen].bounds.size.width - self.imageV.frame.origin.x - 80, 20))];
        [self.contentView addSubview:self.title];
        self.title.font = [UIFont boldSystemFontOfSize:16];
        
        self.listenV = [[UIImageView alloc] initWithFrame:(CGRectMake([UIScreen mainScreen].bounds.size.width - 100, 10, 15, 15))];
        [self.contentView addSubview:self.listenV];
        
        self.count = [[UILabel alloc] initWithFrame:(CGRectMake(self.listenV.x + self.listenV.width + 3, self.listenV.y, 60, 15))];
        [self.contentView addSubview:self.count];
        self.count.font = [UIFont systemFontOfSize:13];
    
        self.author = [[UILabel alloc] initWithFrame:(CGRectMake(self.title.frame.origin.x, self.title.frame.origin.y + self.title.frame.size.height + 5, [UIScreen mainScreen].bounds.size.width - self.title.frame.origin.x, 10))];
        [self.contentView addSubview:self.author];
        self.author.textColor = [UIColor tiankonglan];
        self.author.font = [UIFont boldSystemFontOfSize:13];
        
        self.des = [[UILabel alloc] initWithFrame:(CGRectMake(self.author.frame.origin.x, self.author.frame.origin.y + self.author.frame.size.height, [UIScreen mainScreen].bounds.size.width - self.author.frame.origin.x, 40))];
        [self.contentView addSubview:self.des];
        self.des.numberOfLines = 0;
        self.des.font = [UIFont boldSystemFontOfSize:13];
        self.des.textAlignment = NSTextAlignmentLeft;
        self.des.alpha = 0.5;

        
    }
    return self;
}

-(void)setList:(Alllist *)list
{
    _list = list;
    
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", list.coverimg]] placeholderImage:nil];
    self.title.text = list.title;
    
    NSDictionary *dic = list.userinfo;
    
    NSString *str = [dic objectForKey:@"uname"];
    
    self.author.text = [NSString stringWithFormat:@"by: %@", str];
    
    self.des.text = list.desc;
    
    self.count.text = [NSString stringWithFormat:@"%@", list.count];
    
    self.listenV.image = [UIImage imageNamed:@"bofang"];
    
    
    
}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
