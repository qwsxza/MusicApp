//
//  listCell.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "detaillist.h"

@interface listCell : UITableViewCell

@property(nonatomic, strong)detaillist *list;

@end
