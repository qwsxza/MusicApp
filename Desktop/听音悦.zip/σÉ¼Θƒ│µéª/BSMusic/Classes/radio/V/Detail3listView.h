//
//  Detail3listView.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "radioINfo.h"

@interface Detail3listView : UIView

@property(nonatomic, strong)UITableView  *tableview;

@property(nonatomic, strong)NSMutableArray *modelArr;

@property(nonatomic, strong)radioINfo *infonation;



@end
