//
//  alllistCell.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Alllist.h"

@interface alllistCell : UITableViewCell


@property(nonatomic, strong)Alllist *list;

@end
