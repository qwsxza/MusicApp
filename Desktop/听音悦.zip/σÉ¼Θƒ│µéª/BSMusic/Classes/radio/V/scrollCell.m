//
//  scrollCell.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "scrollCell.h"
#import "firstM.h"
#import "radioInfoController.h"
#import "radioDetailViewController.h"
#import "UIView+Extension.h"
#import "SDCycleScrollView.h"

@interface scrollCell ()<SDCycleScrollViewDelegate>

@property(nonatomic, strong)NSMutableArray *arr;

@end

@implementation scrollCell


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        
        
    }
    return self;
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    self.arr = [NSMutableArray array];
    
    for (int i = 0; i < self.modelArray.count; i++) {
        firstM *new = self.modelArray[i];
        NSString *str = new.img;
        [self.arr addObject:str];
    }
    CGFloat w = self.contentView.bounds.size.width;

    SDCycleScrollView *cycleScrollView2 = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, w, 190) imageURLStringsGroup:self.arr]; // 模拟网络延时情景
    cycleScrollView2.pageControlAliment = SDCycleScrollViewPageContolAlimentRight;
    cycleScrollView2.delegate = self;

    //cycleScrollView2.dotColor = [UIColor yellowColor]; // 自定义分页控件小圆标颜色
    cycleScrollView2.placeholderImage = [UIImage imageNamed:@"placeholder"];
    [self.contentView addSubview:cycleScrollView2];

    
    
}
#pragma mark - SDCycleScrollViewDelegate

- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index
{
//    NSLog(@"---点击了第%ld张图片", index);
    UIViewController *VC = [self viewController];
    
    radioInfoController *infVC = [[radioInfoController alloc] init];
    radioDetailViewController *radioVC = [[radioDetailViewController alloc] init];
    
    
 
        
            firstM *model = [self.modelArray objectAtIndex:index];
            
            NSArray *array = [model.url componentsSeparatedByString:@"/"];
            
            if ([array[2] isEqualToString:@"fm"]) {
                radioVC.API = array[3];
                [VC.navigationController pushViewController:radioVC animated:YES ];
            }
            if ([array[2] isEqualToString:@"ting"]) {
                
                infVC.API = array[3];
                UINavigationController *infNC = [[UINavigationController alloc] initWithRootViewController:infVC];
                
                [VC.navigationController presentViewController:infNC animated:YES completion:nil];
                
            }
            
    
    

    
}



-(void)setModelArray:(NSMutableArray *)modelArray
{
    _modelArray = modelArray;
    
}


/*
-(void)layoutSubviews
{
    [super layoutSubviews];
    
    UIScrollView * scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, self.contentView.width, 200)];
    self.scrollView.contentOffset =  CGPointMake(self.contentView.width, 0);
    
    self.scrollView = scrollView;
    scrollView.pagingEnabled = YES;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.bounces = YES;
    scrollView.delegate = self;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]init];
    [tap addTarget:self action:@selector(tap:)];
    [scrollView addGestureRecognizer:tap];
    
    
    [self.contentView addSubview:scrollView];
    
    
    
  self.pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(self.contentView.frame.size.width/2 + 60, 140, 100, 60)];
   
    self.pageControl.pageIndicatorTintColor = [UIColor yellowColor];
    self.pageControl.currentPageIndicatorTintColor = [UIColor greenColor];
    [self.contentView addSubview:self.pageControl];
    

    self.pageControl.numberOfPages = _modelArray.count - 1;
    self.pageControl.currentPage = 0;
    
    CGFloat with = self.contentView.frame.size.width;
    self.scrollView.contentSize = CGSizeMake(with*_modelArray.count, 190);
   
    for (int i = 0; i < self.modelArray.count; i++) {
        
        UIImageView *imageV = [[UIImageView alloc] init];
        imageV.frame = CGRectMake(i*with, 0, with, 190);
        firstM *new = self.modelArray[i];
        
        
        [imageV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", new.img]] placeholderImage:nil];
        
        [self.scrollView addSubview:imageV];

    }
    
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    CGPoint offSet = scrollView.contentOffset;
    int pageCount = offSet.x/scrollView.frame.size.width;
    
    if (pageCount == self.modelArray.count - 1) {
        _pageControl.currentPage = 0;
    } else{
        
        self.pageControl.currentPage = pageCount ;
        
    }
    
    
}

//滚动时触发
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    
    CGFloat width = scrollView.width;
    CGPoint offset = scrollView.contentOffset;
    
    if (offset.x > width * (self.modelArray.count - 1)) {
        [scrollView setContentOffset:(CGPointZero) animated:NO];
    }
    if (offset.x < 0) {
        [scrollView setContentOffset:(CGPointMake((width * (self.modelArray.count -1)), 0)) animated:NO];
    }
    
}



-(void)setModelArray:(NSMutableArray *)modelArray
{
    _modelArray = modelArray;
    
}

-(void)tap:(UIGestureRecognizer *)tap
{
    UIViewController *VC = [self viewController];
    
    radioInfoController *infVC = [[radioInfoController alloc] init];
    radioDetailViewController *radioVC = [[radioDetailViewController alloc] init];

    
    for (int i = 0; i < self.modelArray.count; i++) {
        if (self.pageControl.currentPage == i) {
            firstM *model = [self.modelArray objectAtIndex:i];
            
            NSArray *array = [model.url componentsSeparatedByString:@"/"];
            
            if ([array[2] isEqualToString:@"fm"]) {
                radioVC.API = array[3];
                [VC.navigationController pushViewController:radioVC animated:YES ];
            }
            if ([array[2] isEqualToString:@"ting"]) {

                infVC.API = array[3];
                UINavigationController *infNC = [[UINavigationController alloc] initWithRootViewController:infVC];
                
                [VC.navigationController presentViewController:infNC animated:YES completion:nil];
                
            }
            
        }
    }
    
    
}
*/
- (UIViewController*)viewController
{
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
