//
//  radioController.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "radioController.h"
#import "NetHandler.h"
#import "firstM.h"
#import "two.h"
#import "Alllist.h"
#import "radioView.h"
#import "MJRefresh.h"
#import "radioDetailViewController.h"
#import "MBProgressHUD.h"


@interface radioController ()<UITableViewDelegate, MBProgressHUDDelegate>



@property(nonatomic, strong)NSMutableArray *arr;

@property(nonatomic, strong)NSMutableArray *arr2;

@property(nonatomic, strong)NSMutableArray *arr3;

@property(nonatomic, strong)radioView *radioview;

@property(nonatomic, strong)MBProgressHUD *HUD;

@property(nonatomic, assign)int count;

@end



@implementation radioController

-(void)viewWillAppear:(BOOL)animated
{
    self.tabBarController.tabBar.hidden = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setNavigationUI];
    self.count = 9;
    
    self.radioview = [[radioView alloc] initWithFrame:(CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height))];
    [self.view addSubview:self.radioview];
    
    
    self.radioview.tableView.delegate = self;
    
    [self setupRefresh];
    
    _HUD = [[MBProgressHUD alloc] initWithView:self.radioview.tableView];
    
    _HUD.labelText = @"数据正在加载";
    
    _HUD.delegate = self;
    
    [self.radioview.tableView addSubview:_HUD];
    
    [_HUD show:YES];

    
    // Do any additional setup after loading the view.
}

- (void)hudWasHidden:(MBProgressHUD *)hud
{
    [hud removeFromSuperview];
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1) {
        
        radioDetailViewController *radioDetailVC = [[radioDetailViewController alloc] init];
        [self.navigationController pushViewController:radioDetailVC animated:YES];
        
        Alllist *list =  self.arr3[indexPath.row];
        
        radioDetailVC.API = list.radioid;
        radioDetailVC.title = list.title;
        
    }
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        
        
        if (indexPath.row == 0) {
            return 200;
        }
        if (indexPath.row == 1) {
            return 120;
        }
    }
    return 85;
}



-(void)handler
{
    self.arr = [NSMutableArray arrayWithCapacity:1];
    
    self.arr2 = [NSMutableArray array];

    self.arr3 = [NSMutableArray array];

    
    [NetHandler getDataWithUrl:[NSString stringWithFormat:@"http://api2.pianke.me/ting/radio"] completion:^(NSData *data) {
        
        
        if (data == nil) {
            return ;
        }
        [_HUD hide:YES afterDelay:0.5];
        

        
        NSDictionary *allDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        
        NSDictionary *dataDic = [allDic objectForKey:@"data"];
        //head
        NSArray *picArr = [dataDic objectForKey:@"carousel"];
//        NSLog(@"%@",picArr);
        
        //two
        NSArray *hostArr = [dataDic objectForKey:@"hotlist"];


        
        //all
        NSArray *allArr = [dataDic objectForKey:@"alllist"];
        
        
        for (NSDictionary *dic in picArr) {
                firstM *one = [[firstM alloc] init];
                [one setValuesForKeysWithDictionary:dic];
                [self.arr addObject:one];
        }
        
        for (NSDictionary *dic1 in hostArr) {
                two *too = [[two alloc] init];
                [too setValuesForKeysWithDictionary:dic1];
                [self.arr2 addObject:too];
        }
        for (NSDictionary *dic2 in allArr) {
            Alllist *all = [[Alllist alloc] init];
            [all setValuesForKeysWithDictionary:dic2];
            [self.arr3 addObject:all];
        }
        
        
        self.radioview.headArr = self.arr;
        
        self.radioview.secondArr = self.arr2;

            
        self.radioview.cellArr = self.arr3;
        
            
    }];
}

-(void)setupRefresh
{
    
       [self handler];
    
    // 1.下拉刷新(进入刷新状态就会调用self的headerRereshing)
//    [self.radioview.tableView addHeaderWithTarget:self action:@selector(headRereshing)];
    
    //进入刷新状态(一进入程序就下拉刷新)
//    [self.radioview.tableView headerBeginRefreshing];
    
    
    // 2.上拉加载更多(进入刷新状态就会调用self的footerRereshing)
    //[self.radioview.tableView addFooterWithTarget:self action:@selector(footerRereshing)];

    
    
    
}
//开始刷新
-(void)headRereshing
{
//    [self handler];
//    NSLog(@"%s", __func__);
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        [self.radioview.tableView reloadData];
        
        // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
        //[self.radioview.tableView headerEndRefreshing];
        
    });

}

//进入加载
-(void)footerRereshing
{
    
    NSURL *postURL = [[NSURL alloc] initWithString:@"http://api2.pianke.me/ting/radio_list"];
    NSMutableURLRequest *requestPost = [[NSMutableURLRequest alloc] initWithURL:postURL cachePolicy:0 timeoutInterval:10];
    [requestPost setHTTPMethod:@"POST"];
    
    NSRange range = {6, 1};
    NSString *str = [@"start=9&client=2&limit=9" stringByReplacingCharactersInRange:range withString:[NSString stringWithFormat:@"%d", _count]];
    
    [requestPost setHTTPBody:[str dataUsingEncoding:NSUTF8StringEncoding]];
//    NSData *data = [NSURLConnection sendSynchronousRequest:requestPost returningResponse:nil error:nil];
    
    [NSURLConnection sendAsynchronousRequest:requestPost queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        
    NSDictionary *allDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        
        
    NSDictionary *dataDic = [allDic objectForKey:@"data"];
    
    NSArray *arr = [dataDic objectForKey:@"list"];
    
    if (arr.count == 0) {
        
        UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"提示" message:@"数据已加载完毕" preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil];
        [alertVC addAction:okAction];
        [self presentViewController:alertVC animated:YES completion:nil];
        
    }
        
    for (NSDictionary *dic in arr) {
        Alllist *all = [[Alllist alloc] init];
        [all setValuesForKeysWithDictionary:dic];
        [self.arr3 addObject:all];
    }
            
   
    self.radioview.cellArr = self.arr3;
    
        
    //[self.radioview.tableView footerEndRefreshing];
    [self.radioview.tableView reloadData];
    _count += 9;
        
        
        
    }];
    
}

-(void)setNavigationUI{
    self.navigationItem.title = @"电台";
    [self.navigationController.navigationBar setBarTintColor:[UIColor blackColor]];
    
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:0.1];
    //UIApplacation设置状态栏的样式
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    
    //设置导航条的标题的字体和颜色（NSForegroundColorAttributeName）
    NSDictionary *titleAttr = @{
                                NSForegroundColorAttributeName:[UIColor lightGrayColor],
                                NSFontAttributeName:[UIFont systemFontOfSize:20]
                                };
    [self.navigationController.navigationBar  setTitleTextAttributes:titleAttr];
    //UITextAttributeTextColor iOS7后被淘汰
    // self.navigationController.navigationBar.titleTextAttributes = @{UITextAttributeTextColor : [UIColor redColor]};
    //设置返回按钮的样式
    //tintColor是用于导航条的所有Item
    self.navigationController.navigationBar .tintColor = [UIColor lightGrayColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
