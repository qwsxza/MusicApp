//
//  radioInfoController.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "radioInfoController.h"
#import "UIView+Extension.h"
#import "OneView.h"
#import "LMusicPlay.h"
//#import "LoginViewController.h"
//#import "UserInfo.h"
//#import <BmobSDK/Bmob.h>
#import "DataHandler.h"

@interface radioInfoController ()<UIScrollViewDelegate, LMusicPlayDelegate>

@property(nonatomic, strong)UIScrollView *BigScrollV;
@property(nonatomic, strong)UIPageControl *pageC;
@property(nonatomic, strong)UIButton *previousB;
@property(nonatomic, strong)UIButton *nextB;
@property(nonatomic, strong)UIButton *playB;
@property(nonatomic, strong)OneView *oneV;

@property(nonatomic, strong)playINFO *play;



@property(nonatomic, strong)NSMutableArray *modelArr;

@property(nonatomic, assign)NSInteger i;

@property(nonatomic, strong)UIWebView *webV;

@property(nonatomic, assign)BOOL isplay;

@property (nonatomic, strong) NSString *url;


@end

@implementation radioInfoController

- (void)viewWillAppear:(BOOL)animated {
    self.tabBarController.tabBar.hidden = YES;
    [super viewWillAppear:animated];
}
- (void)viewDidLoad {
//    NSLog(@"%@", self.API);
    
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.isplay = YES;
    
     self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"diss"] style:(UIBarButtonItemStylePlain) target:self action:@selector(back)];
    
   // self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"收藏" style:(UIBarButtonItemStylePlain) target:self action:@selector(collect)];
    
    self.BigScrollV = [[UIScrollView alloc] initWithFrame:(CGRectMake(0, 0, self.view.width, self.view.height * 6/7))];
    self.BigScrollV.contentSize = CGSizeMake(self.view.width * 2, 0);
    [self.view addSubview:self.BigScrollV];
    self.BigScrollV.showsVerticalScrollIndicator = NO;
    self.BigScrollV.showsHorizontalScrollIndicator = NO;
    self.BigScrollV.pagingEnabled = YES;
    self.BigScrollV.bounces = NO;
    self.BigScrollV.delegate = self;
    
    self.pageC = [[UIPageControl alloc] initWithFrame:(CGRectMake(self.view.width * 1/2 - 20, self.BigScrollV.height - 30, 40, 30))];
    self.pageC.numberOfPages = 2;
    self.pageC.currentPage = 0;
    self.pageC.currentPageIndicatorTintColor = [UIColor greenColor];
    self.pageC.pageIndicatorTintColor = [UIColor yellowColor];
    [self.view addSubview:self.pageC];
    
    
       self.oneV = [[OneView alloc] initWithFrame:(CGRectMake(0, 0, self.view.width, self.BigScrollV.height))];
    [self.BigScrollV addSubview:self.oneV];
    
   
    
    
//添加按钮
    self.previousB = [UIButton buttonWithType:UIButtonTypeCustom];
    self.previousB.frame = CGRectMake(self.view.width * 1/7, self.BigScrollV.y + self.BigScrollV.height + 10 , 44, 44);
    [self.previousB setImage:[UIImage imageNamed:@"front"] forState:(UIControlStateNormal)];
    self.nextB = [UIButton buttonWithType:UIButtonTypeCustom];
    self.nextB.frame = CGRectMake(self.view.width * 4/5 - 30, self.previousB.y, 44, 44);
    [self.nextB setImage:[UIImage imageNamed:@"next"] forState:(UIControlStateNormal)];
    self.playB = [UIButton buttonWithType:UIButtonTypeCustom];
    self.playB.frame = CGRectMake(self.view.width * 1/2 - 22 , self.previousB.y, 44, 44);
    [self.playB setImage:[UIImage imageNamed:@"pause"] forState:(UIControlStateNormal)];
    [self.view addSubview:self.previousB];
    [self.view addSubview:self.nextB];
    [self.view addSubview:self.playB];
    
    [self.previousB addTarget:self action:@selector(front:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.nextB addTarget:self action:@selector(next:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.playB addTarget:self action:@selector(play:) forControlEvents:(UIControlEventTouchUpInside)];

    
    [self.oneV.silder addTarget:self action:@selector(valueChange:) forControlEvents:(UIControlEventValueChanged)];
     self.oneV.silder.minimumValue = 0.0;

    [LMusicPlay shareLmusicPlay].delegate = self;

#pragma mark -- 再次点击继续上次播放
    DataHandler *data = [DataHandler shareDataHandler];
    
    if ([data.info.tingid isEqualToString:self.API]) {
        
        self.oneV.play = data.info;
        self.oneV.totallabel.text = [self strWithTimeInterval:data.totalTime];
        
        NSMutableURLRequest *reQUS = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", data.info.webview_url]]];
        reQUS.timeoutInterval = 20;
        
        if (self.webV) {
            [self.webV removeFromSuperview];
            self.webV = nil;
        }
        
        self.webV = [[UIWebView alloc] initWithFrame:(CGRectMake(self.view.width , 0, self.view.width, self.BigScrollV.height))];
        [self.BigScrollV addSubview:self.webV];
        
        //进行网络请求
        [self.webV loadRequest:reQUS];
        [self.webV reload];//刷新
        
        
    } else {
        
        [self handler:self.API];
        
    }
    
    //接受通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(starPlay) name:@"readyToPlay" object:nil];
    
    // Do any additional setup after loading the view.
}
#pragma mark -- 收藏按钮
/*
-(void)collect
{
    UserInfo *user = [UserInfo sharedUserInfo];
    if (user.isLogin) {
        [self favoriteRadio];
    } else {
        LoginViewController *loginVC = [[LoginViewController alloc] init];
        __block typeof(self) blockSelf = self;
        loginVC.block = ^(id userInfo) {
            [blockSelf favoriteRadio];
        };
        [self.navigationController pushViewController:loginVC animated:YES];;
    }
    //self.API 传入的ID
    //self.IDtitle 传入的标题;
    
    
    
}
*/
/*
- (void)favoriteRadio {
     UserInfo *user = [UserInfo sharedUserInfo];
    // 1.判断活动是否收藏过
    //BOOL isFavorite = NO;
    BmobQuery *bquery = [BmobQuery queryWithClassName:@"Favorite"];
    NSArray *array = @[@{@"username":user.username, @"favoriteId":self.API}];
    [bquery addTheConstraintByAndOperationWithArray:array];
    [bquery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        if (array.count != 0) {
            // 插入操作
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"该活动已经被收藏过了" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
            return ;
        } else {
            BmobObject *favoriteObject = [BmobObject objectWithClassName:@"Favorite"];
            NSDictionary *dic = @{@"username":user.username, @"favoriteId":self.API, @"type":@"电台", @"title":self.IDtitle};
            [favoriteObject saveAllWithDictionary:dic];
            [favoriteObject saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                if (isSuccessful ) {
                    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"收藏成功" delegate:nil cancelButtonTitle:@"确认" otherButtonTitles:nil];
                    [alertView show];
//                    [//self performSelector:@selector(removeAlertView:) withObject:alertView afterDelay:0.3];
                }
                else {
                    NSLog(@"%@", error);
                }
            }];
        }
    }];
}

*/

-(void)back{
   // [self dismissViewControllerAnimated:YES completion:nil];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)audioManagerStreamer:(LMusicPlay *)streamer songProgress:(float)songProgress
{
    DataHandler *data = [DataHandler shareDataHandler];
    self.oneV.silder.maximumValue = data.totalTime;

    self.oneV.silder.value = songProgress;
    
    self.oneV.timelabel.text = [self strWithTimeInterval:songProgress];

}
//转化秒数
- (NSString *)strWithTimeInterval:(float)interval
{
    int m = (int)interval / 60;
    int s = (int)interval % 60;
    return [NSString stringWithFormat:@"%0.2d: %0.2d", m , s];
}
//开始播放(通知发生)
-(void)starPlay
{
    CMTime total = [LMusicPlay shareLmusicPlay].playItem.duration;
    
    self.oneV.silder.maximumValue = total.value / total.timescale;
    float allTime  = self.oneV.silder.maximumValue;
    DataHandler *data = [DataHandler shareDataHandler];
    data.totalTime = allTime;

    self.oneV.totallabel.text = [self strWithTimeInterval:allTime];
    
    
    [[LMusicPlay shareLmusicPlay] startPlay];
    
}

#pragma mark--解析
-(void)handler:(NSString *)str
{
    self.modelArr = [NSMutableArray array];
    
    NSURL *postUrl = [NSURL URLWithString:@"http://api2.pianke.me/ting/info"];
    NSMutableURLRequest *requesrt = [[NSMutableURLRequest alloc] initWithURL:postUrl cachePolicy:0 timeoutInterval:10];
    [requesrt setHTTPMethod:@"POST"];
    
    NSString *str1 = [NSString stringWithFormat:@"auth=&client=1&deviceid=3A00DB22-23CD-4BFA-852E-BCD3647FEE12&tingid=%@&version=3.0.6", str];
    
    [requesrt setHTTPBody:[str1 dataUsingEncoding:NSUTF8StringEncoding]];
    [NSURLConnection sendAsynchronousRequest:requesrt queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        NSDictionary *dataDic = [dic objectForKey:@"data"];
        
        NSDictionary *play = [dataDic objectForKey:@"playInfo"];
        
        playINFO *playin = [[playINFO alloc] init];
        
        [playin setValuesForKeysWithDictionary:play];
        
        self.oneV.play = playin;
        
        DataHandler *dataID = [DataHandler shareDataHandler];
        
        dataID.info = playin;
        
        NSString *mp3URl = playin.musicUrl;
        self.url = mp3URl;
        [[LMusicPlay shareLmusicPlay] playWithUrl:mp3URl];
        
        [[LMusicPlay shareLmusicPlay] startPlay];
        
    
        NSMutableURLRequest *reQUS = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", playin.webview_url]]];
        reQUS.timeoutInterval = 20;

        if (self.webV) {
            [self.webV removeFromSuperview];
            self.webV = nil;
        }
        
        self.webV = [[UIWebView alloc] initWithFrame:(CGRectMake(self.view.width , 0, self.view.width, self.BigScrollV.height))];
        [self.BigScrollV addSubview:self.webV];
        
        //进行网络请求
        [self.webV loadRequest:reQUS];
        [self.webV reload];//刷新
        
    }];
}



- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView

{
    CGPoint offSet = scrollView.contentOffset;
    CGFloat width  = scrollView.frame.size.width;

    NSUInteger page =  offSet.x / width;
    
    self.pageC.currentPage = page;
}

//滑块方法
-(void)valueChange:(UISlider *)slider
{
    [[LMusicPlay shareLmusicPlay] seekToTime:slider.value];
}

//播放,暂停
-(void)play:(UIButton *)button
{
    if (self.isplay) {
        [self.playB setImage:[UIImage imageNamed:@"play"] forState:(UIControlStateNormal)];
       
         [[LMusicPlay shareLmusicPlay] stopPlay];
        self.isplay = NO;
    } else {
        [self.playB setImage:[UIImage imageNamed:@"pause"] forState:(UIControlStateNormal)];
        
        [[LMusicPlay shareLmusicPlay] startPlay];
        self.isplay = YES;
    }
}

//下一首
-(void)front:(UIButton *)button
{
    
    self.i = [self.idArr indexOfObject:self.API];
    self.i --;
    if (self.i < 0) {
       
        self.i = self.idArr.count - 1;
    
        self.API = self.idArr[self.i];
        [self handler:self.API];
        
    } else {
        self.API = self.idArr[self.i];
        [self handler:self.API];

    }
    
}
//上一首
-(void)next:(UIButton *)button
{
    
    self.i = [self.idArr indexOfObject:self.API];
    self.i ++;
    if (self.i >= self.idArr.count - 1) {
        
          self.i = 0;
        
        self.API = self.idArr[self.i];
        [self handler:self.API];
        
    } else {
        self.API = self.idArr[self.i];
        [self handler:self.API];
        
    }
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
