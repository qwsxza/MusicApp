//
//  radioDetailViewController.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface radioDetailViewController : UIViewController

@property(nonatomic, strong)NSString *API;

@property(nonatomic, strong)NSString *name;

@end
