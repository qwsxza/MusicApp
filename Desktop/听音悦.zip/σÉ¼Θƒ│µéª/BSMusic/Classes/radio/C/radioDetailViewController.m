//
//  radioDetailViewController.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "radioDetailViewController.h"
#import "Detail3listView.h"
//#import "MJRefresh.h"
#import "detaillist.h"
#import "radioINfo.h"
#import "radioInfoController.h"
#import "detaillist.h"
#import "HeadView.h"
#import "MBProgressHUD.h"



@interface radioDetailViewController ()<UITableViewDelegate, MBProgressHUDDelegate>

@property(nonatomic, strong)Detail3listView *detailView;
@property(nonatomic, strong)HeadView *headV;

@property(nonatomic, strong)NSMutableArray *arr;

@property(nonatomic, strong)NSDictionary *info;

@property(nonatomic, strong)NSMutableArray *IDarr;
@property(nonatomic, strong)MBProgressHUD *HUD;
@property(nonatomic, assign)int count;
@end

@implementation radioDetailViewController

-(void)viewWillAppear:(BOOL)animated
{
    self.tabBarController.tabBar.hidden = YES;

}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.count = 10;
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"back"] style:(UIBarButtonItemStylePlain) target:self action:@selector(back)];
    
    self.headV = [[HeadView alloc] initWithFrame:(CGRectMake(0, 0, self.view.bounds.size.width, 240))];
    
    self.detailView = [[Detail3listView alloc] initWithFrame:(CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height))];
    [self.view addSubview:self.detailView];
    
    self.detailView.tableview.tableHeaderView = [[UIView alloc] initWithFrame:(CGRectMake(0, 0, self.view.bounds.size.width, 20))];
  
    self.detailView.tableview.delegate = self;
    
    self.detailView.tableview.tableHeaderView = self.headV;
    
    [self setupRefresh];
    
    
    _HUD = [[MBProgressHUD alloc] initWithView:self.detailView.tableview];
    
    _HUD.labelText = @"数据正在加载";
    
    _HUD.delegate = self;
    
    [self.detailView.tableview addSubview:_HUD];
    
    [_HUD show:YES];
    // Do any additional setup after loading the view.
}


-(void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)hudWasHidden:(MBProgressHUD *)hud
{
    [hud removeFromSuperview];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    radioInfoController *radioinVC = [[radioInfoController alloc] init];
    detaillist *list = self.detailView.modelArr[indexPath.row];
    radioinVC.API = list.tingid;
    radioinVC.idArr = self.IDarr;
    radioinVC.IDtitle = list.title;
//    UINavigationController *radioNC = [[UINavigationController alloc] initWithRootViewController:radioinVC];
    
    
    [self.navigationController pushViewController:radioinVC animated:YES];
//    [self.navigationController pushViewController:radioNC animated:YES];

    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    if (indexPath.row == 0) {
//        return 240;
//    }
    
    return 65;
}

//数据解析
-(void)handler
{
    self.info = [NSDictionary dictionary];
    self.arr = [NSMutableArray array];
    
    self.IDarr = [NSMutableArray array];
    
    NSURL *postUrl = [NSURL URLWithString:@"http://api2.pianke.me/ting/radio_detail"];
    NSMutableURLRequest *requestPost = [[NSMutableURLRequest alloc] initWithURL:postUrl cachePolicy:0 timeoutInterval:10];
    
    [requestPost setHTTPMethod:@"POST"];
    
    NSString *str = [NSString stringWithFormat:@"radioid=%@&start=0&client=2&limit=10", self.API];
    
    [requestPost setHTTPBody:[str dataUsingEncoding:NSUTF8StringEncoding]];
//    NSData *data = [NSURLConnection sendSynchronousRequest:requestPost returningResponse:nil error:nil];
    [NSURLConnection sendAsynchronousRequest:requestPost queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        
        if (data == nil) {
            return ;
        }
        [_HUD hide:YES afterDelay:1];
        
        

        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
    
    
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    NSDictionary *dic1 = [dic objectForKey:@"data"];
    
    NSDictionary *dic2 = [dic1 objectForKey:@"radioInfo"];
    
    radioINfo *radioIN = [[radioINfo alloc] init];
    
    [radioIN setValuesForKeysWithDictionary:dic2];
    
    self.title = radioIN.title;
            
            
    NSArray *arr = [dic1 objectForKey:@"list"];
        
            
    
    for (NSDictionary *dic2 in arr) {
        detaillist *dlist = [[detaillist alloc] init];
        [dlist setValuesForKeysWithDictionary:dic2];
        [self.IDarr addObject:dlist.tingid];
        [self.arr addObject:dlist];
    }
    dispatch_async(dispatch_get_main_queue(), ^{

    self.detailView.modelArr = self.arr;
        self.headV.infonation = radioIN;

//    self.detailView.infonation = radioIN;

         });
    });
  }];
}


-(void)setupRefresh
{
    [self handler];
    
//    // 1.下拉刷新(进入刷新状态就会调用self的headerRereshing)
//    [self.detailView.tableview addHeaderWithTarget:self action:@selector(headRereshing)];
    
    //进入刷新状态(一进入程序就下拉刷新)
//    [self.detailView.tableview headerBeginRefreshing];
    
    
    // 2.上拉加载更多(进入刷新状态就会调用self的footerRereshing)
    //[self.detailView.tableview addFooterWithTarget:self action:@selector(footerRereshing)];
    
    
    
    
}
//开始刷新
-(void)headRereshing
{
//    [self handler];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        [self.detailView.tableview reloadData];
        
        // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
       // [self.detailView.tableview headerEndRefreshing];
        
    });
    
}

//进入加载
-(void)footerRereshing
{
    
    NSURL *postURL = [[NSURL alloc] initWithString:@"http://api2.pianke.me/ting/radio_detail_list"];
    NSMutableURLRequest *requestPost = [[NSMutableURLRequest alloc] initWithURL:postURL cachePolicy:0 timeoutInterval:10];
    [requestPost setHTTPMethod:@"POST"];

    
    NSString *str =[NSString stringWithFormat:@"radioid=%@&start=%d&client=2&limit=10", self.API, _count];
    

    [requestPost setHTTPBody:[str dataUsingEncoding:NSUTF8StringEncoding]];

    [NSURLConnection sendAsynchronousRequest:requestPost queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {

    
    NSDictionary *allDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        
    NSDictionary *dataDic = [allDic objectForKey:@"data"];
    
    NSArray *arr = [dataDic objectForKey:@"list"];

    if (arr.count == 0) {
            
            UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"提示" message:@"数据已加载完毕" preferredStyle:(UIAlertControllerStyleAlert)];
            
            UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil];
            [alertVC addAction:okAction];
            [self presentViewController:alertVC animated:YES completion:nil];
            
    }
    
        
        
    for (NSDictionary *dic in arr) {
        detaillist *all = [[detaillist alloc] init];
        [all setValuesForKeysWithDictionary:dic];
        
        [self.IDarr addObject:all.tingid];
        
        [self.arr addObject:all];
    }
     dispatch_async(dispatch_get_main_queue(), ^{
        
    self.detailView.modelArr = self.arr;
    
    
    
    //[self.detailView.tableview footerEndRefreshing];
    [self.detailView.tableview reloadData];

    _count += 10;
    
      });  
     });
    }];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
