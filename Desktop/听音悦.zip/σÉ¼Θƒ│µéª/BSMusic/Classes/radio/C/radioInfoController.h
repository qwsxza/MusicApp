//
//  radioInfoController.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "playINFO.h"


@interface radioInfoController : UIViewController

@property(nonatomic, strong)AVPlayer *player;
@property(nonatomic, strong)AVPlayerItem *playerItem;

@property(nonatomic, strong)NSString *API;//传入ID
@property(nonatomic, strong)NSMutableArray *idArr;
@property(nonatomic, strong)NSString *IDtitle;//传入标题



@end
