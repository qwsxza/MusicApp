//
//  radioINfo.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface radioINfo : NSObject

@property(nonatomic, strong)NSString *title;
@property(nonatomic, strong)NSString *coverimg;
@property(nonatomic, strong)NSString *desc;
@property(nonatomic, strong)NSDictionary *userinfo;
@property(nonatomic, strong)NSString *musicvisitnum;



@end
