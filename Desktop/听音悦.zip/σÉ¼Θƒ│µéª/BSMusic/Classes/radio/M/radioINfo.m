//
//  radioINfo.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "radioINfo.h"

@implementation radioINfo

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
