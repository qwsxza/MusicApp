//
//  Alllist.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Alllist : NSObject


@property(nonatomic, strong)NSString *radioid; //拼接id
@property(nonatomic, strong)NSString *title;
@property(nonatomic, strong)NSString *coverimg; //图片地址
@property(nonatomic, strong)NSDictionary *userinfo;
@property(nonatomic, strong)NSString *count;
@property(nonatomic, strong)NSString *desc;
@property(nonatomic, strong)NSString *isnew;


@end
