//
//  firstM.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface firstM : NSObject

@property(nonatomic, strong)NSString *img;

@property(nonatomic, strong)NSString *url;

@end
