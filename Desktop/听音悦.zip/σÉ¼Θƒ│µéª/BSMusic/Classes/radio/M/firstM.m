//
//  firstM.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "firstM.h"

@implementation firstM

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}


@end
