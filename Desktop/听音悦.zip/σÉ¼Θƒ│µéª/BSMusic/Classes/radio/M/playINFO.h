//
//  playINFO.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface playINFO : NSObject

@property(nonatomic, strong)NSString *title;
@property(nonatomic, strong)NSString *imgUrl;//图片地址
@property(nonatomic, strong)NSString *musicUrl;//MP3地址
@property(nonatomic, strong)NSString *webview_url;//webview地址
@property(nonatomic, strong)NSString *tingid;


@end
