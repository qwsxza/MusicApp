//
//  DataHandler.h
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "playINFO.h"
@interface DataHandler : NSObject

@property(nonatomic, strong)playINFO *info;

@property(nonatomic, assign)float totalTime;

+(DataHandler *)shareDataHandler;

@end
