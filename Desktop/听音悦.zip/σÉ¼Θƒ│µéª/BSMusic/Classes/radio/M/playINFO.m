//
//  playINFO.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "playINFO.h"

@implementation playINFO

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
