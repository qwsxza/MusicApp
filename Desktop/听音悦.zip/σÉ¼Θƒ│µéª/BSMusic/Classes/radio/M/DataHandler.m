//
//  DataHandler.m
//  BSMusic
//
//  Created by tarena on 16/4/16.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "DataHandler.h"


static DataHandler *handler;

@implementation DataHandler


+(DataHandler *)shareDataHandler
{
    @synchronized(self) {
        if (handler == nil) {
            handler = [[DataHandler alloc] init];
        }
        return handler;
    }
}

@end
