//
//  DateBaseManager.h
//  BSMusic
//
//  Created by MyMac on 16/5/9.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDB.h"

@interface DateBaseManager : NSObject
+ (FMDatabase *)sharedDatabase;
@end
