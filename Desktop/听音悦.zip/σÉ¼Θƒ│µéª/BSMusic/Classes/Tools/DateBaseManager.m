//
//  DateBaseManager.m
//  BSMusic
//
//  Created by MyMac on 16/5/9.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "DateBaseManager.h"

@implementation DateBaseManager
+ (FMDatabase *)sharedDatabase {
    //使用GCD的一次性任务实现两个逻辑
    static FMDatabase *database = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        //NSFileManager: 单例 + 方法
        //目标数据库文件的路径
        NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
        NSString *targetDBPath = [documentPath stringByAppendingPathComponent:@"sqlite.db"];
        
        if (![[NSFileManager defaultManager] fileExistsAtPath:targetDBPath]) {
            //2.初始化database
            database = [FMDatabase databaseWithPath:targetDBPath];
            
        }
        
    });
    
    [database open];
    return database;
}
@end
