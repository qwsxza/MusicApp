//
//  PreMuicList.h
//  BSMusic
//
//  Created by MyMac on 16/5/9.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PreMuicList : NSObject

@property (nonatomic, strong) NSString *SongName;
@property (nonatomic, strong) NSString *SingerName;
@property (nonatomic, assign) NSInteger FavourCount;


+ (NSArray *)kinds;
//给定用户选择的诗词的名字,返回是否删除成功
//+ (BOOL)removeKind:(NSString *)kindStr;
@end
