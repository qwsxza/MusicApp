//
//  PreMuicList.m
//  BSMusic
//
//  Created by MyMac on 16/5/9.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "PreMuicList.h"
#import "DateBaseManager.h"

@implementation PreMuicList
+ (NSMutableArray *)kinds {
    FMDatabase *database = [DateBaseManager sharedDatabase];
    FMResultSet *resultSet = [database executeQuery:@"select * from T_KIND"];
    NSMutableArray *mutablArray = [NSMutableArray array];
    
    while ([resultSet next]) {
        PreMuicList *music = [self new];
        music.SongName = [resultSet stringForColumn:@"song_name"];
        music.SingerName = [resultSet stringForColumn:@"songer_name"];
        music.FavourCount = [resultSet doubleForColumn:@"pick_count"];
        
        //添加赋值后的诗集对象
        [mutablArray addObject:music];
    }
    return [mutablArray copy];
}
@end
