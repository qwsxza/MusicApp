//
//  LoopButton.h
//  BSMusic
//
//  Created by tarena on 16/4/14.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoopButton : UIButton
- (void)setLoopImages:(NSArray *)images;

- (void)setLoopImages:(NSArray *)images andHighlightedImages:(NSArray *)highlightedImages;

@property (nonatomic) NSUInteger currentIndex;
@end
