//
//  PlayingViewController.m
//  BSMusic
//
//  Created by tarena on 16/4/14.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "PlayingViewController.h"
#import "LocalMusic.h"
#import <AVFoundation/AVFoundation.h>
#import "MusicTool.h"
#import "AudioTool.h"
#import "UIView+Extension.h"
#import "UIImage+Circle.h"
#import "LoopButton.h"

//#import "UINavigationController+FDFullscreenPopGesture.h"
#import "PlayerHelper.h"
#import "MusicModel.h"
#import "UIImageView+WebCache.h"
#import "MBProgressHUD.h"
#import "BottomPlayView.h"
#import "NSTimer+Control.h"
#import "RecordDBHelper.h"
#import "PlayRecordEntity.h"
#import "DateBaseManager.h"

#define FLAG_MAIN_PAD_STATE_CLOSING     1
#define FLAG_MAIN_PAD_STATE_CLOSED      2
#define FLAG_MAIN_PAD_STATE_OPENING     3
#define FLAG_MAIN_PAD_STATE_OPENED      4

#define FLAG_PROGRESS_SLIDER_STATE_NORMAL           1
#define FLAG_PROGRESS_SLIDER_STATE_MOVING_BY_USER   2

#define FLAG_PLAYING_STATE_PAUSE    0
#define FLAG_PLAYING_STATE_PLAYING  1


@interface PlayingViewController ()<AVAudioPlayerDelegate>//监听歌曲播放完毕，自动切换到下一首
{
    BOOL isRandom;
}

@property (weak, nonatomic) IBOutlet UIView *mainPadView;
/** imageSong 歌曲图片 */
@property (weak, nonatomic) IBOutlet UIImageView *albumImageView;
@property (weak, nonatomic) IBOutlet UIImageView *albumImageReflectionView;
@property (weak, nonatomic) IBOutlet UIImageView *controlPadBackground;
/**  SongName 歌曲标签*/
@property (weak, nonatomic) IBOutlet UILabel *mainTitleLabel;
/** Singer 歌手标签 */
@property (weak, nonatomic) IBOutlet UILabel *subtitleLabel;
@property (weak, nonatomic) IBOutlet UIView *functionPadView;
@property (weak, nonatomic) IBOutlet UIImageView *functionPadBackground;
@property (weak, nonatomic) IBOutlet UIButton *playingModeButton;
@property (weak, nonatomic) IBOutlet UISlider *volumeSlider;

@property (weak, nonatomic) IBOutlet UIButton *backButton;
/**  DuratiionTime 音频总时长*/
@property (weak, nonatomic) IBOutlet UILabel *durationTimeLabel;

@property (weak, nonatomic) IBOutlet UISlider *sliderControl;
/** CurrentTime 当前时间*/
@property (weak, nonatomic) IBOutlet UILabel *currentTimeLabel;
@property (weak, nonatomic) IBOutlet UIButton *playButton;
/** 设置当前正在播放的音乐 */
@property (nonatomic, strong) Music *currentPlayingMusic;
/** 存储当前播放器 */
@property (nonatomic, strong) AVAudioPlayer *player;
/** 存储当前定时器对象 */
@property (nonatomic, strong) NSTimer *progressTimer;
/**  states */
@property (nonatomic) unsigned int flagMainPadState;
@end

@implementation PlayingViewController

#pragma mark - playViewController 单例
+ (PlayingViewController *)sharePlayViewController {
    static PlayingViewController *player = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        player = [[PlayingViewController alloc]init];
    });
    return player;
}



#pragma mark - 初始化
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if (self) {
        [self initialize];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initialize];
    }
    return self;
}

- (void)initialize
{
    self.hidesBottomBarWhenPushed = YES;
    self.flagMainPadState = FLAG_MAIN_PAD_STATE_CLOSED;
}


#pragma mark - button相关触发方法
//改变播放模式
- (IBAction)RandomActionButton:(id)sender {
    MBProgressHUD *mb = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    mb.mode = MBProgressHUDModeText;
    
    if (!isRandom) {
        [sender setImage:[UIImage imageNamed:@"playing_random_btn_h"] forState:UIControlStateNormal];
        isRandom = YES;
        mb.labelText = @"随机模式";
    } else {
        [sender setImage:[UIImage imageNamed:@"playing_single_btn_h"] forState:UIControlStateNormal];
        isRandom = NO;
        mb.labelText = @"顺序模式";
    }
    [[NSUserDefaults standardUserDefaults] setBool:isRandom forKey:@"isRandom"];
    [mb hide:YES afterDelay:0.5];

    
}


- (IBAction)clickPlayButton:(id)sender {
   
     // 1.获取button当前的状态
     if (self.playButton.selected)
     {
     // 修改状态：暂停 －> 显示播放
     self.playButton.selected = NO;
     //2.暂停音乐播放
     [AudioTool pauseMusicWithFilename:self.currentPlayingMusic.filename];
     
     } else {
     
     // 修改状态：播放 －> 显示的暂停
     self.playButton.selected = YES;
     [self startPlayingMusic];
     }
    
    
    //如果当前播放不存在，则返回
    if (!_currentItem) {
        return;
    }
    PlayerHelper *player = [PlayerHelper sharePlayerHelper];
    BOOL isPlaying = [[NSUserDefaults standardUserDefaults] boolForKey:@"isPlaying"];
    if (isPlaying) {
        [[BottomPlayView shareBottomPlayView].lineImage stopAnimating];
        [player.aPlayer pause];
        [[BottomPlayView shareBottomPlayView].playerTimer pauseTimer];
        [_playButton setImage:[UIImage imageNamed:@"playing_btn_play_n"] forState:UIControlStateNormal];
    } else {
        [player.aPlayer play];
        [[BottomPlayView shareBottomPlayView].playerTimer resumeTimer];
        [_playButton setImage:[UIImage imageNamed:@"playing_btn_pause_n"] forState:UIControlStateNormal];
    }
    [[NSUserDefaults standardUserDefaults] setBool:!isPlaying forKey:@"isPlaying"];

}

- (IBAction)clickPreviousButton:(id)sender {
   /*
    // 1.重置数据
    [self resetPlayingMusic];
    // 2.设置当前播放音乐
    [MusicTool setCurrentPlayingMusic:[MusicTool previousMusic]];
    // 3.开始播放
    [self startPlayingMusic];
   */
    NSLog(@"-------------");
    //如果当前播放不存在，则返回
    if (!_currentItem) {

        return;
    }
    if (_dataArr.count == 1) {
        MBProgressHUD *mb = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        mb.mode = MBProgressHUDModeText;
        mb.labelText = @"-.-只有一首歌";
        [mb hide:YES afterDelay:0.5];
        return;
    }
    //将上一个Item置为nil， 为下一个播放做准备
    [BottomPlayView shareBottomPlayView].playerItem = nil;
    if (--_currentIndex >= 0) {
        [self setUpPlayDataWithMusicModel:_dataArr[_currentIndex]];
    } else {
        _currentIndex = _dataArr.count - 1;
        [self setUpPlayDataWithMusicModel:_dataArr[_dataArr.count - 1]];
    }
    [self setUpBottomView];
}

- (IBAction)clickNextButton:(id)sender {
    
    // 1.重置数据
    [self resetPlayingMusic];
    // 2.设置当前播放音乐
    [MusicTool setCurrentPlayingMusic:[MusicTool nextMusic]];
    // 3.开始播放
    [self startPlayingMusic];
    
    
    //如果当前播放不存在，则返回
    if (!_currentItem) {
        return;
    }
    if (_dataArr.count == 1) {
        MBProgressHUD *mb = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        mb.mode = MBProgressHUDModeText;
        mb.labelText = @"-.-只有一首歌";
        [mb hide:YES afterDelay:0.5];
        return;
    }
    //判断是不是随机模式
    if (isRandom) {
        [self randomPlaySong];
    } else {
        [self nextSong];
    }
    
}
- (IBAction)clickBackButton:(id)sender {
    
    // 1.获取Window
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [self dismissViewControllerAnimated:YES completion:nil];
    // 2.执行退出动画
    [UIView animateWithDuration:1 animations:^{
        self.view.y = window.bounds.size.height;
        
    } completion:^(BOOL finished) {
    }];

}
#pragma mark UISlider事件
//值改变,拖动的过程中
- (void)sliderValueChanged:(UISlider *)slider {
    //如果当前播放不存在，则返回
    if (!_currentItem) {
        return;
    }
    self.currentTimeLabel.text = [self timeformatFromSeconds:slider.value];
    [[BottomPlayView shareBottomPlayView].playerTimer pauseTimer];
}
//拖动结束
- (void)sliderDragDone:(UISlider *)slider {
    //如果当前播放不存在，则返回
    if (!_currentItem) {
        self.sliderControl.value = 0;
        return;
    }
    [[BottomPlayView shareBottomPlayView].playerTimer resumeTimer];
    self.sliderControl.value = slider.value;
    //秒转成CMTime
    CMTime dragedCMTime = CMTimeMake(slider.value, 1);
    [[PlayerHelper sharePlayerHelper].aPlayer pause];
    [[PlayerHelper sharePlayerHelper].aPlayer seekToTime:dragedCMTime completionHandler:^(BOOL finished) {
        [[PlayerHelper sharePlayerHelper].aPlayer play];
    }];
}

#pragma mark - 数据库
- (void)InsertData:(NSString *)SongName SingerName:(NSString *)SingerName FavoriteCount:(NSInteger)FavoriteCount MusicUrl:(NSString*)MusicUrl{
    if ([[DateBaseManager sharedDatabase] open]) {
        BOOL isSuccess = [[DateBaseManager sharedDatabase] executeUpdateWithFormat:@"insert into music (song_name, songer_name, pick_count, music_url) values (%@, %@, %ld, %@)",SongName,SingerName,FavoriteCount,MusicUrl];
        
        if (!isSuccess) {
            NSLog(@"插入数据失败:%@",[DateBaseManager sharedDatabase].lastError);
        }
    }
}

#pragma mark -布局子视图方法
- (void)setupSubviews
{
    
    UIImage * backgroundImageForFunctionPad = [[UIImage imageNamed:@"playing_toolbar_bg.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(16, 16, 16, 16) resizingMode:UIImageResizingModeStretch];
    self.functionPadBackground.image = backgroundImageForFunctionPad;
    
    UIImage * imageForProgressNow = [[UIImage imageNamed:@"playing_slider_play_left.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(1, 1, 2, 1)];
    [self.sliderControl setMinimumTrackImage:imageForProgressNow forState:UIControlStateNormal];
    UIImage * imageForProgressTotal = [[UIImage imageNamed:@"playing_slider_buf_right.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(1, 1, 2, 1)];
    [self.sliderControl setMaximumTrackImage:imageForProgressTotal forState:UIControlStateNormal];
    [self.sliderControl setThumbImage:[UIImage imageNamed:@"playing_slider_thumb.png"] forState:UIControlStateNormal];
      UIImage * imageForVolumeNow = [[UIImage imageNamed:@"playing_volumn_slide_foreground.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(5, 5, 5, 5) resizingMode:UIImageResizingModeStretch];
    [self.volumeSlider setMinimumTrackImage:imageForVolumeNow forState:UIControlStateNormal];
    UIImage * imageForVolumeTotal = [[UIImage imageNamed:@"playing_volumn_slide_bg.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(5, 5, 5, 5) resizingMode:UIImageResizingModeStretch];
    [self.volumeSlider setMaximumTrackImage:imageForVolumeTotal forState:UIControlStateNormal];
    [self.volumeSlider setThumbImage:[UIImage imageNamed:@"playing_volumn_slide_sound_icon.png"] forState:UIControlStateNormal];
     [self.sliderControl addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    //拖动后
    [self.sliderControl addTarget:self action:@selector(sliderDragDone:) forControlEvents:UIControlEventTouchUpInside];
}

#pragma mark - AVAudioPlayerDelegate
// 播放结束时调用
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    //播放下一首歌曲(相当于点击下一个button)
    [self clickNextButton:self];
}

#pragma mark - 定时器相关方法
// 开启定时器
- (void)addProgressTimer
{
    //1.是否正在播放
    if(self.player.playing == NO) return;
    
    
    //2. 设置滑块点击的触发方法(刚点击)
    [self.sliderControl addTarget:self action:@selector(touchDown) forControlEvents:UIControlEventTouchDown];
    
    //3. 设置滑块松开的触发方法(停止点击)
    [self.sliderControl addTarget:self action:@selector(touchUpInside) forControlEvents:UIControlEventTouchUpInside];
    
    // 4.创建定时器
    self.progressTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateCurrentSliderValue) userInfo:nil repeats:YES];
}



//使用定时器自定更新slider
- (void)updateCurrentSliderValue {
    //1.计算进度
    double progress = self.player.currentTime / self.player.duration;
    
    //2.设置当前slider的value
    self.sliderControl.value = progress;
    
    //3.设置当前label值
    self.currentTimeLabel.text = [self stringFormatWithTimeInterval:self.player.currentTime];
}

//取消定时器定时功能
- (void)removeProgressTimer
{
    [self.progressTimer invalidate];
    self.progressTimer = nil;
}

#pragma mark - 点击slider触发方法
- (void)touchDown {
    //停止定时器
    [self removeProgressTimer];
}

- (void)touchUpInside {
    
    //1.通过slider的value重新计算player的当前播放时间
    self.player.currentTime = self.sliderControl.value * self.player.duration;
    
    //2.设置当前label值
    self.currentTimeLabel.text = [self stringFormatWithTimeInterval:self.player.currentTime];
    
    //3.如果当前正在播放，重新开启定时器
    if (self.player.playing) {
        [self addProgressTimer];
    }
    
}


#pragma mark - 显示视图
- (void)showPlayingView
{
    //1.判断是否为当前歌曲(否则多个音乐播放)
    if(self.currentPlayingMusic != [MusicTool currentPlayingMusic])
    {
        // 重置数据
        [self resetPlayingMusic];
    }
    
    //2.获取Window
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    self.view.frame = window.bounds;
    
    //3.将view添加到window上
    [window addSubview:self.view];
    
    //4.设置view的y值
    self.view.y = window.bounds.size.height;
    
    //5.执行动画
    [UIView animateWithDuration:1 animations:^{
        // 执行动画
        self.view.y = 0;
    } completion:^(BOOL finished) {
        // 开始播放
        [self startPlayingMusic];
    }];
}

- (void)showPlayView{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    self.view.frame = window.bounds;
    
    //3.将view添加到window上
    [window addSubview:self.view];
    
    //4.设置view的y值
    self.view.y = window.bounds.size.height;
    
    //5.执行动画
    [UIView animateWithDuration:1 animations:^{
        // 执行动画
        self.view.y = 0;
    } completion:^(BOOL finished) {
        
    }];

}



// 开始播放
- (void)startPlayingMusic
{
    //1.获取正在播放的音乐模型对象
    Music *music = [MusicTool currentPlayingMusic];
    
    //2.播放音乐
    self.player = [AudioTool playMusicWithFilename:music.filename];
    
    //3.设置播放器的代理
    self.player.delegate = self;
    
    //4.赋值给当前播放音乐对象
    self.currentPlayingMusic = [MusicTool currentPlayingMusic];
    
    //5.设置当前的button为暂停
    self.playButton.selected = YES;
    
    //6.设置总时长text
    self.durationTimeLabel.text = [self stringFormatWithTimeInterval:self.player.duration];
    
    //7.启动定时器
    [self addProgressTimer];
}

//转换格式
- (NSString *)stringFormatWithTimeInterval:(NSTimeInterval)interval
{
    int minute = interval / 60;
    int second = (int)interval % 60;
    return [NSString stringWithFormat:@"%02d: %02d", minute , second];
}

//将控件赋值为初始值
- (void)resetPlayingMusic
{
    //当前时长
    self.currentTimeLabel.text = @"00:00";
    //总时长
    self.durationTimeLabel.text = @"03:30";
    
    //停止正在播放的歌曲
    [AudioTool stopMusicWithFilename:self.currentPlayingMusic.filename];
}

#pragma mark -生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupSubviews];
    //判断bottom传来的Item是否是正在播放的
    if (_currentItem) {
        self.currentTimeLabel.text = [self timeformatFromSeconds:CMTimeGetSeconds(_currentItem.currentTime) - 1];
        self.durationTimeLabel.text = [self timeformatFromSeconds:CMTimeGetSeconds(_currentItem.duration)];
        self.sliderControl.maximumValue = CMTimeGetSeconds(_currentItem.duration);
        self.sliderControl.value = CMTimeGetSeconds(_currentItem.currentTime);
    }
    isRandom = [[NSUserDefaults standardUserDefaults] boolForKey:@"isRandom"];
    if (isRandom) {
        [self.playingModeButton setImage:[UIImage imageNamed:@"repeat4.png"] forState:UIControlStateNormal];
    }
    [self setUpPlayDataWithMusicModel: _dataArr[_currentIndex]];
   
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.sliderControl.value = 0;
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self setUpBottomView];
}

#pragma mark - 重新给bottomView赋值
- (void)setUpBottomView {
    BottomPlayView *bpv = [BottomPlayView shareBottomPlayView];
    MusicModel *model = _dataArr[_currentIndex];
    bpv.dataSourceArr = _dataArr;
    bpv.currentIndex = _currentIndex;
    bpv.Singer.text = model.singer_name == nil ? @"听音悦提醒" : model.singer_name;
    bpv.SongName.text = model.song_name == nil ? @"没有选择播放的歌曲" : model.song_name;
    bpv.currentItem = _currentItem;
    //由于接口数据问题，只能传送用户图片，找不到歌手图片
    bpv.pic_url = self.pic_url;
    [bpv.songImage sd_setImageWithURL:[NSURL URLWithString:self.pic_url] placeholderImage:[UIImage imageNamed:@"default.jpg"]];
    
}

#pragma mark - 时间格式化
- (NSString *)timeformatFromSeconds:(NSInteger)seconds {
    NSInteger totalm = seconds/(60);
    NSInteger h = totalm/(60);
    NSInteger m = totalm%(60);
    NSInteger s = seconds%(60);
    if (h == 0) {
        return  [NSString stringWithFormat:@"%02ld:%02ld", (long)m, (long)
                 s];
    }
    return [NSString stringWithFormat:@"%02ld:%02ld:%02ld", (long)h, (long)m, (long)s];
}

#pragma mark 设置数据
- (void)setUpPlayDataWithMusicModel:(MusicModel *)model {
    
    self.mainTitleLabel.text = model.song_name;
    self.subtitleLabel.text = model.singer_name;
    //处理歌名过长的情况
    //self.lblSong_Height.constant = [self getTextHeight:_lblSongName.text] > 21 ? 42 : 21;
    
    
    BottomPlayView *bpv = [BottomPlayView shareBottomPlayView];
    //从bottomPlayView正在播放过来
    if (bpv.playerItem.status == AVPlayerStatusReadyToPlay) {
        bpv.ASTimer = ^(AVPlayerItem *item) {
            [self handleActionTime:item];
        };
    } else {
        [[BottomPlayView shareBottomPlayView] setupPlayerWithModel:model];
        bpv.ASTimer = ^(AVPlayerItem *item) {
            [self handleActionTime:item];
        };
    }
    //播放下一首
    bpv.NextSong = ^() {
        //给系统一个延迟，准备播放下一首(如果不延迟，将不能自己播放下一首ps:或许player还没有准备好播放)
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (isRandom) {
                [self randomPlaySong];
            } else {
                [self nextSong];
            }
        });
    };
}

#pragma mark - 计时器
- (void)handleActionTime:(AVPlayerItem *)newItem {
    self.durationTimeLabel.text = [self timeformatFromSeconds:CMTimeGetSeconds(newItem.duration)];
    self.currentTimeLabel.text = [self timeformatFromSeconds:CMTimeGetSeconds(newItem.currentTime)];
    //这里需要存储一下当前的playerItem,以便pop时，还给bottomView
    _currentItem = newItem;
    _sliderControl.maximumValue = CMTimeGetSeconds(newItem.duration);
    _sliderControl.value = CMTimeGetSeconds(newItem.currentTime);
    
}

#pragma mark - 随机播放一首歌
- (void)randomPlaySong {
    NSInteger index = arc4random() % _dataArr.count;
    //将当期页设置为随机的数
    _currentIndex = index;
    [BottomPlayView shareBottomPlayView].playerItem = nil;
    [self setUpPlayDataWithMusicModel:_dataArr[index]];
    [self setUpBottomView];
}

#pragma mark - 获取下一首歌曲
- (void)nextSong {
    //将上一个Item置为nil,为下一个播放做准备
    [BottomPlayView shareBottomPlayView].playerItem = nil;
    if (++_currentIndex >= _dataArr.count) {
        _currentIndex = 0;
        [self setUpPlayDataWithMusicModel:[_dataArr firstObject]];
    } else {
        [self setUpPlayDataWithMusicModel:_dataArr[_currentIndex]];
    }
    [self setUpBottomView];
}
@end
