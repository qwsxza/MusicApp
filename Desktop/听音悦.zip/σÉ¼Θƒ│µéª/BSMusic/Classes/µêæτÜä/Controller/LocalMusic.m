//
//  LocalMusic.m
//  BSMusic
//
//  Created by tarena on 16/4/13.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "LocalMusic.h"
#import "PlayingViewController.h"
#import "MusicTool.h"
#import "Music.h"
#import <Masonry.h>
#import "PlayMusicTableViewCell.h"

@interface LocalMusic()<UITableViewDataSource,UITableViewDelegate>
/** 本地所有数据数组*/
@property (nonatomic, strong) NSArray *localMusicArray;

/** 播放界面*/
@property (nonatomic, strong) PlayingViewController *playingViewController;
@property (nonatomic,strong) UITableView *tableView;
@end
@implementation LocalMusic

#pragma mark - 懒加载
-(NSArray *)localMusicArray{
    if (!_localMusicArray) {
        _localMusicArray = [MusicTool musicArray];
    }
    return _localMusicArray;
}
-(PlayingViewController *)playingViewController{
    if (!_playingViewController) {
        _playingViewController = [[PlayingViewController alloc]init];
    }
    return _playingViewController;
}

-(UITableView*)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]init];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        //[_tableView registerClass:[PlayMusicTableViewCell class]forCellReuseIdentifier:@"musicCell"];
       [_tableView registerNib:[UINib nibWithNibName:@"PlayMusicTableViewCell" bundle:nil] forCellReuseIdentifier:@"PlayMusicTableViewCell"];
        
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _tableView;
}

#pragma mark -生命周期
-(void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"本地音乐列表";
    self.navigationController.navigationBar .tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"返回"style:UIBarButtonItemStyleBordered target:self action:@selector(backAction)];
    UISwipeGestureRecognizer *recognize = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(OnLeftButton)];
    [recognize setDirection:(UISwipeGestureRecognizerDirectionRight|UISwipeGestureRecognizerDirectionLeft)];
    [self.view addGestureRecognizer:recognize];
    NSLog(@"%@",self.localMusicArray);
    /** 这句太关键了*/
    [self.tableView reloadData];
}

- (void)backAction{
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark - tableView 代理方法
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.localMusicArray.count;
   
    
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    PlayMusicTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PlayMusicTableViewCell" forIndexPath:indexPath];
    Music *music =self.localMusicArray[indexPath.row];
        cell.imageView.image = [UIImage imageNamed:music.singerIcon];
    cell.textLabel.text = music.name;
    cell.detailTextLabel.text = music.singer;
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 1.主动取消选中
  [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    // 2.设置当前播放的音乐
    //获取选中行对应的音乐模型对象
    Music *music = self.localMusicArray[indexPath.row];
    [MusicTool setCurrentPlayingMusic:music];
    
    [self.playingViewController showPlayingView];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}

-(void)OnLeftButton{
   [self dismissViewControllerAnimated:YES completion:nil];
}

@end
