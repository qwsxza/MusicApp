//
//  LeftViewController.h
//  ThreeViewsText
//
//  Created by lanouhn on 16/2/29.
//  Copyright © 2016年 杨杰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftViewController : UIViewController
//存放当前播放的数据源
@property (nonatomic, strong) NSMutableArray *dataSourceArr;
@property (nonatomic,assign) NSInteger currentIndex;
//传送到播放页面的数据
@property (nonatomic, copy) void ((^TapshakeButton)(NSMutableArray *dataArr,NSInteger currentIndex));
@end
