//
//  LeftViewController.m
//  ThreeViewsText
//
//  Created by lanouhn on 16/2/29.
//  Copyright © 2016年 杨杰. All rights reserved.
//

#import "LeftViewController.h"
#import "LocalMusic.h"
#import "MBProgressHUD.h"
#import "SDImageCache.h"
#import "PlayingViewController.h"
#import "favourViewController.h"

@interface LeftViewController ()

@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic,strong)PlayingViewController* playViewController;
@end

@implementation LeftViewController
- (PlayingViewController *)playViewController{
    if (!_playViewController) {
        _playViewController = [[PlayingViewController alloc]init];
    }
    return _playViewController;
}

- (void)viewDidLoad {
    [super viewDidLoad];
   // self.view.backgroundColor = [UIColor whiteColor];
    self.view.alpha = 1;
    [self addConstraint];
    
    LeftViewController *lvc = [[LeftViewController alloc]init];
    lvc.TapshakeButton = ^(NSMutableArray *dataArr,NSInteger currentIndex){
        self.playViewController.dataArr = dataArr;
        self.playViewController.currentIndex = currentIndex;
        [self.playViewController showPlayView];
    };
   
}


/**
 *  创建控件, 添加约束
 */
- (void)addConstraint {
    // 头像图片
    UIImageView *headImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"头像"]];
    
    headImage.layer.masksToBounds = YES;
    
    headImage.layer.cornerRadius = 45;
    
    headImage.translatesAutoresizingMaskIntoConstraints = NO;
    
    [self.view addSubview:headImage];
    
    
    
    UIButton *tanName = [UIButton buttonWithType:(UIButtonTypeSystem)];
    
    [tanName.titleLabel setFont:[UIFont systemFontOfSize:18.0]];
    
    tanName.tintColor = [UIColor whiteColor];
    
    tanName.titleLabel.textAlignment = NSTextAlignmentLeft;
    
    [tanName setTitle:@"" forState:(UIControlStateNormal)];
    [tanName addTarget:self action:@selector(localMusic) forControlEvents:UIControlEventTouchUpInside];
    
    tanName.translatesAutoresizingMaskIntoConstraints = NO;
    
    [self.view addSubview:tanName];
    
    
    UIButton *messageButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
    
    messageButton.titleLabel.font = [UIFont systemFontOfSize:18.0];
    
    messageButton.titleLabel.textAlignment = NSTextAlignmentLeft;
    
    messageButton.tintColor = [UIColor whiteColor];
    
    [messageButton setTitle:@"清除缓存" forState:(UIControlStateNormal)];
    [messageButton addTarget:self action:@selector(clean) forControlEvents:UIControlEventTouchUpInside];
    
    messageButton.translatesAutoresizingMaskIntoConstraints = NO;
    
    [self.view addSubview:messageButton];
    
    
    
    UIButton *gButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
    
    gButton.titleLabel.textAlignment = NSTextAlignmentLeft;
    
    gButton.titleLabel.font = [UIFont systemFontOfSize:18.0];
    
    gButton.tintColor = [UIColor whiteColor];
    
    [gButton setTitle:@"最近播放" forState:(UIControlStateNormal)];
    [gButton addTarget:self action:@selector(shake) forControlEvents:UIControlEventTouchUpInside];
    
    gButton.translatesAutoresizingMaskIntoConstraints = NO;
    
    [self.view addSubview:gButton];
    
    
    
    UIButton *settingsButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
    
    settingsButton.titleLabel.textAlignment = NSTextAlignmentLeft;
    
    settingsButton.titleLabel.font = [UIFont systemFontOfSize:18.0];
    
    settingsButton.tintColor = [UIColor whiteColor];
    
    [settingsButton setTitle:@"" forState:(UIControlStateNormal)];
    
    settingsButton.translatesAutoresizingMaskIntoConstraints = NO;
    
    [self.view addSubview:settingsButton];
    
    
    
    
    UIButton *newPeopleButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
    
    newPeopleButton.titleLabel.textAlignment = NSTextAlignmentLeft;
    
    newPeopleButton.titleLabel.font = [UIFont systemFontOfSize:18.0];
    
    newPeopleButton.tintColor = [UIColor whiteColor];
    
    [newPeopleButton setTitle:@"" forState:(UIControlStateNormal)];
    //[newPeopleButton addTarget:self action:@selector(clean) forControlEvents:UIControlEventTouchUpInside];
    
    newPeopleButton.translatesAutoresizingMaskIntoConstraints = NO;
    
    [self.view addSubview:newPeopleButton];
    
    
    
    UIButton *recommendPeopleButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
    
    recommendPeopleButton.titleLabel.textAlignment = NSTextAlignmentLeft;
    
    recommendPeopleButton.titleLabel.font = [UIFont systemFontOfSize:18.0];
    
    recommendPeopleButton.tintColor = [UIColor whiteColor];
    
    [recommendPeopleButton setTitle:@"" forState:(UIControlStateNormal)];
    
    //[recommendPeopleButton addTarget:self action:@selector(checkEdition) forControlEvents:UIControlEventTouchUpInside];
    
    recommendPeopleButton.translatesAutoresizingMaskIntoConstraints = NO;
    
    [self.view addSubview:recommendPeopleButton];
    
    
    NSDictionary *views = NSDictionaryOfVariableBindings(headImage, tanName, gButton, messageButton, settingsButton, newPeopleButton, recommendPeopleButton);
    
    NSArray *imageHC = [NSLayoutConstraint constraintsWithVisualFormat:@"H:[headImage(90)]" options:NSLayoutFormatAlignAllCenterX metrics:nil views:views];
    
    
    NSArray *imageV = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-60-[headImage(90)]-110-[tanName]-10-[messageButton]-10-[gButton]-10-[settingsButton]-10-[newPeopleButton]-10-[recommendPeopleButton]-50-|" options:(NSLayoutFormatAlignAllCenterX) metrics:nil views:views];
    
    NSLayoutConstraint *centerX = [NSLayoutConstraint constraintWithItem:headImage attribute:(NSLayoutAttributeCenterX) relatedBy:(NSLayoutRelationEqual) toItem:self.view attribute:(NSLayoutAttributeCenterX) multiplier:1 constant:0];
    
    
    NSArray *tanArray = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[tanName]-0-|" options:0 metrics:0 views:views];
    
    
    NSArray *messageArray = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[messageButton]-0-|" options:0 metrics:0 views:views];
    
    NSArray *settingsArray = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[settingsButton]-0-|" options:0 metrics:0 views:views];
    
    NSArray *newPeopleArray = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[newPeopleButton]-0-|" options:0 metrics:0 views:views];
    
    NSArray *gButtonArray = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[gButton]-0-|" options:0 metrics:0 views:views];
    
    
    
    NSArray *recommendPeopleButtonArray = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[recommendPeopleButton]-0-|" options:0 metrics:0 views:views];
    
    
    
    NSLayoutConstraint *tanWigth = [NSLayoutConstraint constraintWithItem:tanName attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:gButton attribute:(NSLayoutAttributeHeight) multiplier:1 constant:0];
    
    
    
    NSLayoutConstraint *gButtonWigth = [NSLayoutConstraint constraintWithItem:gButton attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:tanName attribute:(NSLayoutAttributeHeight) multiplier:1 constant:0];
    
    
    NSLayoutConstraint *messageButtonWigth = [NSLayoutConstraint constraintWithItem:gButton attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:messageButton attribute:(NSLayoutAttributeHeight) multiplier:1 constant:0];
    
    
    NSLayoutConstraint *settingsButtonWigth = [NSLayoutConstraint constraintWithItem:gButton attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:settingsButton attribute:(NSLayoutAttributeHeight) multiplier:1 constant:0];
    
    
    NSLayoutConstraint *newPeopleButtonWigth = [NSLayoutConstraint constraintWithItem:settingsButton attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:newPeopleButton attribute:(NSLayoutAttributeHeight) multiplier:1 constant:0];
    
    
    NSLayoutConstraint *recommendPeopleButtonWigth = [NSLayoutConstraint constraintWithItem:settingsButton attribute:(NSLayoutAttributeHeight) relatedBy:(NSLayoutRelationEqual) toItem:recommendPeopleButton attribute:(NSLayoutAttributeHeight) multiplier:1 constant:0];
    
    
    [self.view addConstraint:centerX];
    
    [self.view addConstraints:imageHC];
    
    [self.view addConstraints:imageV];
    
    [self.view addConstraints:gButtonArray];
    
    [self.view addConstraints:recommendPeopleButtonArray];
    
    [self.view addConstraints:tanArray];
    
    [self.view addConstraints:messageArray];
    
    [self.view addConstraints:settingsArray];
    
    [self.view addConstraints:newPeopleArray];
    
    [self.view addConstraints:@[tanWigth, gButtonWigth, messageButtonWigth, settingsButtonWigth, newPeopleButtonWigth, recommendPeopleButtonWigth]];

}

-(void)localMusic{
    LocalMusic *vc = [[LocalMusic alloc]init];
    UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:vc];
   
    [self presentViewController:navi animated:YES completion:nil];
    
}

- (void)clean{
    MBProgressHUD *hud = [[MBProgressHUD alloc] init];
    [self.view addSubview:hud];
    //加载条上显示文本
    hud.labelText = @"急速清理中";
    //设置对话框样式
    hud.mode = MBProgressHUDModeDeterminate;
    [hud showAnimated:YES whileExecutingBlock:^{
        while (hud.progress < 1.0) {
            hud.progress += 0.01;
            [NSThread sleepForTimeInterval:0.02];
        }
        hud.labelText = @"清理完成";
        [NSThread sleepForTimeInterval:0.5];
    } completionBlock:^{
       [[SDImageCache sharedImageCache] clearMemory];
        [hud removeFromSuperview];
    }];
}

- (void)checkEdition{
    //1.获取服务器的版本号
    //2.获取本地版本号[从bundle里获取]
    NSDictionary *info = [[NSBundle mainBundle] infoDictionary];
    NSLog(@"%@",info);
    // NSString *lacalVersion = info[@"CFBundleShortVersionString"];
    
    //对比
    NSLog(@"正在检查版本更新");
    
    // 给一个假象
    MBProgressHUD *hud = [[MBProgressHUD alloc] init];
    [self.view addSubview:hud];
    //加载条上显示文本
    hud.labelText = @"正在检查版本更新中...";
    hud.mode = MBProgressHUDModeDeterminateHorizontalBar;
    [hud showAnimated:YES whileExecutingBlock:^{
        while (hud.progress < 1.0) {
            hud.progress += 0.01;
            [NSThread sleepForTimeInterval:0.02];
        }
        hud.labelText = @"当前已经是最新版本";
        [NSThread sleepForTimeInterval:0.5];
    } completionBlock:^{
        [hud removeFromSuperview];
    }];
  /*
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUD];
        [MBProgressHUD showSuccess:@"当前已经是最新版本"];
    });
   */

}

- (void)shake{
    favourViewController *vc = [[favourViewController alloc]init];
    UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:vc];
    
    [self presentViewController:navi animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}


@end
