//
//  favourViewController.m
//  BSMusic
//
//  Created by MyMac on 16/5/1.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import "favourViewController.h"
#import <Masonry.h>
#import "MusicListTableViewCell.h"
#import "MusicModel.h"
#import "DateBaseManager.h"
#import "MusicModel.h"
#import "PlayingViewController.h"
#import "BottomPlayView.h"
#import "MusicUrlModel.h"

@interface favourViewController ()<UITableViewDataSource,UITableViewDelegate>{
    NSInteger pIndex; //上次播放的索引
}

@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) NSMutableArray* dataSourceArr;
@end

@implementation favourViewController

-(UITableView*)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]init];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerNib:[UINib nibWithNibName:@"MusicListTableViewCell" bundle:nil] forCellReuseIdentifier:@"MusicListTableViewCell"];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            //make.edges.mas_equalTo(0);
            make.top.left.bottom.right.mas_equalTo(self.view).insets(UIEdgeInsetsMake(0, 0, 0, 0));
        }];
    }
    return _tableView;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataSourceArr.count;
}
- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MusicModel *model = _dataSourceArr[indexPath.row];
    MusicListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MusicListTableViewCell" forIndexPath:indexPath];
    cell.SongName.text = [NSString stringWithFormat:@"%d. %@", (int)indexPath.row + 1, model.song_name];
    cell.model = model;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 90;
}
//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    if (indexPath.section == 0) {
//        //处理，点击的还是同一首歌
//        if (pIndex != indexPath.row -1) {
//            BottomPlayView *bpv = [BottomPlayView shareBottomPlayView];
//            MusicModel *model = _dataSourceArr[indexPath.row];
//            bpv.dataSourceArr = _dataSourceArr;
//            bpv.currentIndex = indexPath.row;
//    
//            [PlayingViewController sharePlayViewController].dataArr = _dataSourceArr;
//            [PlayingViewController sharePlayViewController].currentIndex = indexPath.row;
//            //播放
//            [[PlayingViewController sharePlayViewController] showPlayView];
//            [bpv setupPlayerWithModel:model];
//            pIndex = indexPath.row;
//            
//        }
//    }
//}
- (void)viewWillAppear:(BOOL)animated{
    self.navigationItem.title = @"最近播放";
    self.navigationController.navigationBar .tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"返回"style:UIBarButtonItemStyleBordered target:self action:@selector(backAction)];
    FMDatabase *database = [DateBaseManager sharedDatabase];
    [database open];
    FMResultSet *resultSet = [database executeQuery:@"select * from music"];
    NSMutableArray *mutablArray = [NSMutableArray array];
    
    while ([resultSet next]) {
        MusicModel *music = [MusicModel new];
        MusicUrlModel *musicUrl = [MusicUrlModel new];
        music.song_name = [resultSet stringForColumn:@"song_name"];
        music.singer_name = [resultSet stringForColumn:@"songer_name"];
        music.pick_count = [resultSet doubleForColumn:@"pick_count"];
        musicUrl.music_url = [resultSet stringForColumn:@"music_url"];
        music.url_list = [NSMutableArray arrayWithObject:musicUrl.music_url];
        //添加赋值后的诗集对象
        [mutablArray addObject:music];
        
    }
    self.dataSourceArr = mutablArray;
    [self.tableView reloadData];
    NSLog(@"%@",self.dataSourceArr);

}

- (void)backAction{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)viewDidLoad {
    [super viewDidLoad];
        self.view.backgroundColor = [UIColor whiteColor];
    
    UISwipeGestureRecognizer *recognize = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(OnLeftButton)];
    [recognize setDirection:(UISwipeGestureRecognizerDirectionRight|UISwipeGestureRecognizerDirectionLeft)];
    [self.view addGestureRecognizer:recognize];
    
}

- (void)OnLeftButton{
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (NSMutableArray*)readData{
   
    FMDatabase *database = [DateBaseManager sharedDatabase];
    FMResultSet *resultSet = [database executeQuery:@"select * from music"];
    NSMutableArray *mutablArray = [NSMutableArray array];
    
    while ([resultSet next]) {
        MusicModel *music = [MusicModel new];
        music.song_name = [resultSet stringForColumn:@"song_name"];
        music.singer_name = [resultSet stringForColumn:@"songer_name"];
        music.pick_count = [resultSet doubleForColumn:@"pick_count"];
        
        //添加赋值后的诗集对象
        [mutablArray addObject:music];
     
    }
    return [mutablArray copy];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

@end
