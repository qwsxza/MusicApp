//
//  AudioTool.h
//  BSMusic
//
//  Created by tarena on 16/4/14.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface AudioTool : NSObject
/** 根据音乐文件名称播放音乐*/
+ (AVAudioPlayer *)playMusicWithFilename:(NSString  *)filename;

/** 根据音乐文件名称暂停音乐*/
+ (void)pauseMusicWithFilename:(NSString  *)filename;

/** 根据音乐文件名称停止音乐*/
+ (void)stopMusicWithFilename:(NSString  *)filename;
@end
