//
//  MusicTool.h
//  BSMusic
//
//  Created by tarena on 16/4/13.
//  Copyright © 2016年 YJ-Xcode. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Music.h"

@interface MusicTool : NSObject
/** 获取所有音乐 (读取plist文件；使用单例设计模式)*/
+ (NSArray *)musicArray;

/** 设置当前正在播放的音乐*/
+ (void)setCurrentPlayingMusic:(Music *)music;

/** 返回当前正在播放的音乐*/
+ (Music *)currentPlayingMusic;

/** 获取下一首*/
+ (Music *)nextMusic;

/** 获取上一首*/
+ (Music *)previousMusic;

@end
